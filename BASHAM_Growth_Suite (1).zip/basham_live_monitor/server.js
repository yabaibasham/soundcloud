const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) { for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) { const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/); if (m && !Object.prototype.hasOwnProperty.call(process.env, m[1])) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2'); } }
const PORT = Number(process.env.PORT || 8080);
const CLIENT_ID = process.env.SOUNDCLOUD_CLIENT_ID || '';
const PUBLIC = path.join(__dirname, 'public');
const allowedHost = 'api.soundcloud.com';
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
function send(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'null'});res.end(JSON.stringify(obj));}
async function sc(pathname){
  if(!CLIENT_ID || CLIENT_ID === 'PASTE_YOUR_CLIENT_ID_HERE') throw new Error('Add your SoundCloud client ID to .env or the SOUNDCLOUD_CLIENT_ID environment variable.');
  const u = new URL('https://'+allowedHost+pathname); u.searchParams.set('client_id',CLIENT_ID);
  const r = await fetch(u,{headers:{accept:'application/json'}});
  const raw = await r.text(); let data; try{data=JSON.parse(raw)}catch{data={message:raw.slice(0,200)}};
  if(!r.ok) throw new Error(`SoundCloud API returned ${r.status}: ${data.message || data.error_description || 'request failed'}`);
  return data;
}
async function resolveTrack(input){
  let u; try{u=new URL(input)}catch{throw new Error('Enter a full SoundCloud track URL.');}
  if(!['soundcloud.com','www.soundcloud.com','m.soundcloud.com','on.soundcloud.com'].includes(u.hostname)) throw new Error('Only SoundCloud links are supported.');
  const found = await sc('/resolve?url='+encodeURIComponent(u.href));
  if(!found || !found.id || !found.permalink_url) throw new Error('That link did not resolve to a public track.');
  return found;
}
async function trackMetrics(input){
  const t = await resolveTrack(input);
  const id = t.id || t.urn;
  const track = await sc('/tracks/'+encodeURIComponent(id));
  let commentsCount = track.comment_count ?? null;
  let commentsSample = [];
  if(commentsCount === null || commentsCount === undefined){
    try { const c=await sc('/tracks/'+encodeURIComponent(id)+'/comments?limit=1&linked_partitioning=true'); commentsCount=c.total_results ?? c.collection?.length ?? null; commentsSample=c.collection||[]; } catch {}
  }
  return {id:track.id, title:track.title || t.title || 'Untitled track', artist:track.user?.username || t.user?.username || 'Unknown artist', url:track.permalink_url || t.permalink_url || input,
    artwork:track.artwork_url || track.user?.avatar_url || null,
    plays:track.playback_count ?? null, likes:track.likes_count ?? null, reposts:track.reposts_count ?? null,
    comments:commentsCount, duration_ms:track.duration ?? null, last_updated:new Date().toISOString(), api_fields:{playback_count:track.playback_count!==undefined,likes_count:track.likes_count!==undefined,reposts_count:track.reposts_count!==undefined,comment_count:track.comment_count!==undefined},
    note:'Counts reflect fields made available by SoundCloud API credentials and may be delayed or omitted by the platform.'};
}
const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://localhost');
  if(req.method==='GET' && u.pathname==='/api/status') return send(res,200,{configured:!!CLIENT_ID&&CLIENT_ID!=='PASTE_YOUR_CLIENT_ID_HERE',api:'SoundCloud public API',poll_seconds:Math.max(30,Math.min(600,Number(process.env.POLL_SECONDS||60)))});
  if(req.method==='POST' && u.pathname==='/api/metrics'){
    let body=''; req.on('data',d=>{body+=d;if(body.length>20000)req.destroy()}); req.on('end',async()=>{try{const parsed=JSON.parse(body||'{}');const links=[...new Set((Array.isArray(parsed.links)?parsed.links:[]).map(x=>String(x).trim()).filter(Boolean))].slice(0,25);if(!links.length)return send(res,400,{error:'Paste one or more SoundCloud track links.'});const results=await Promise.all(links.map(async link=>{try{return {input:link,ok:true,data:await trackMetrics(link)}}catch(e){return {input:link,ok:false,error:e.message}}}));send(res,200,{results,checked_at:new Date().toISOString()});}catch(e){send(res,400,{error:'Invalid JSON request.'})}});return;
  }
  if(req.method==='GET' && u.pathname==='/api/health')return send(res,200,{ok:true});
  const rel=u.pathname==='/'?'index.html':decodeURIComponent(u.pathname.slice(1));const file=path.resolve(PUBLIC,rel);if(!file.startsWith(PUBLIC+path.sep)&&file!==path.join(PUBLIC,'index.html')){res.writeHead(403);return res.end('Forbidden');}
  fs.readFile(file,(err,buf)=>{if(err){res.writeHead(404,{'content-type':'text/plain'});return res.end('Not found');}res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});res.end(buf)});
});
server.listen(PORT,'127.0.0.1',()=>console.log(`BASHAM Live Monitor: http://127.0.0.1:${PORT}`));
