# BASHAM Live Monitor

A small local dashboard that accepts SoundCloud track URLs, resolves them through the official API, displays API-provided plays/likes/reposts/comments where available, polls every 60 seconds while open, and exports CSV.

## Requirements
- Node.js 20+
- Your own SoundCloud API client ID, obtained at https://soundcloud.com/you/apps
- API access must be granted and used within SoundCloud's terms. The application cannot grant itself API access.

## Start
1. Copy `.env.example` to `.env` and set `SOUNDCLOUD_CLIENT_ID`.
2. In a terminal, run `npm start`.
3. Open http://127.0.0.1:8080

If you do not use a dotenv loader, set the variable in your shell before starting:
- macOS/Linux: `SOUNDCLOUD_CLIENT_ID=your_id node server.js`
- Windows PowerShell: `$env:SOUNDCLOUD_CLIENT_ID='your_id'; node server.js`

This app intentionally does not scrape SoundCloud pages or generate fake engagement. Counts can be absent, delayed, or restricted by API permissions. “Live” means periodically refreshed API snapshots, not a guaranteed real-time event stream.


## Growth suite (free-only configuration)
The dashboard now also includes a cross-platform content/campaign planner and a manual campaign-results log. It drafts posts for the five configured tracks and common channels (SoundCloud, TikTok, Instagram Reels, YouTube Shorts, and X), stores task checklists and campaign results in the browser's local storage, and exports campaign results to CSV. Paid spend is planned at $0; this tool does not create ads, charge money, auto-post, or generate artificial engagement. Enter views/clicks/engagements from each platform's own analytics to compare campaigns.

## Recommended free-first workflow
1. Start with one short hook clip per track and vary the angle (hook, lyric breakdown, behind-the-track story).
2. Share only in communities that allow self-promotion and contact artists/pages personally rather than mass-spamming.
3. Use track-specific links and campaign tags in your notes; log results after 24 hours and again after 7 days.
4. Compare clicks and genuine engagement, not just views. If a platform offers official artist analytics, use those numbers rather than estimates.
5. No ad campaign is launched from this local dashboard. Any future paid promotion must be configured and approved directly in the advertising platform; this project keeps the planned spend at $0.
