# Campaign ideas — all five BASHAM tracks

Written for a 14-day sprint with no label, no budget and no team. The assumption is a
small but real audience that already listens to you, plus a handful of small communities
that don't yet.

These are plans, not posts. Everything is editable in the planner.

---

## Positioning

Five tracks, one lane. That's a release sprint, not five campaigns. The mistake is
treating them as independent — you burn your audience five times over and get five weak
signals instead of one strong push.

**Lead with the two that travel.** `WILD FIRE` (biggest clip potential) and
`LETS GO CITY GRIND` (raw freestyle, no polish barrier) will do the reach. `RAINY DAYS`
does the depth. `VELVET DAMAGE` is the one people argue about later, which is worth
something, but it is not your reach track. `Demons & Daemon's BURN CITY` is the anchor
— it's your longest-established track, so it converts existing listeners.

**Post one thing per day, maximum.** Two posts a day reads as spam and halves the
per-post impact.

---

## Day by day

### Day 1 — the freestyle drops
- **SoundCloud:** republish `LETS GO CITY GRIND` with a clean title and correct artwork.
  Check the waveform art before pushing — a wrong thumbnail costs plays permanently.
- **Instagram:** Story announcement only. Reply to every DM with the link; that's where
  the actual conversion happens.

### Day 2 — mood content
- **SoundCloud:** `RAINY DAYS` goes up.
- **TikTok:** the cleanest 15 seconds of the hook. Caption stays near-silent. Text hooks
  outperform audio hooks at this length.

### Day 3 — the hard one
- **Playlist pitch:** `VELVET DAMAGE` to curators who like a challenge. SubmitHub or
  direct email. Aim 15 submissions, accept 3–5 — a 20% acceptance rate is normal.
- **X:** quote post, tag two producers or DJs you actually respect.

### Day 4 — the banger
- **SoundCloud / Instagram / TikTok:** `WILD FIRE` everywhere, same hour. This is your
  highest-volume day; don't fragment it.
- **TikTok:** beat-switch clip. The transition *is* the video.
- **Instagram:** Reel using audio straight from SoundCloud so it registers as a play.

### Day 5 — community
- **Discord:** ask which track hits. Reply to every answer — this is the cheapest
  engagement you'll get all sprint.
- **SoundCloud:** repost the catalogue, lead with the strongest.

### Day 6 — email
- **Email list:** `WILD FIRE` single. **Only if you have a genuine opted-in list.**
  Never buy lists; it destroys deliverability and it's the fastest route to a spam
  complaint.

### Day 7 — press
- **Blog / press:** the angle isn't "new music," it's *independent artist, five-track run,
  from the ground, no label*. Local hip-hop press, student radio, campus papers. Student
  radio actively wants unplayed artists.

### Day 8 — long form
- **YouTube:** full freestyle session, one take. YouTube has the longest tail of any
  platform here. Title for search: "BASHAM freestyle".

### Day 9 — midpoint
- **SoundCloud:** check your own numbers. Repost whichever track actually moved. The seed
  plan guesses; your dashboard knows.

### Day 10 — bars on screen
- **Instagram:** carousel of screenshots of the hardest `VELVET DAMAGE` lines. No caption
  needed — the screenshots are the content. Last slide: link in bio.

### Day 11 — second pitch round
- **Playlist:** different curators than day 3. Track who responds; that list is worth
  more than the plays.

### Day 12 — ask for something
- **Discord:** "Rainy Days — what do you want on part two?" People who answer are your
  actual core. This list is the whole point of the sprint.

### Day 13 — radio
- **Live / radio:** five tracks, independent, available now. Community and student radio
  still take unplayed artists.

### Day 14 — close and reset
- **SoundCloud:** thank them, next one is done. Then review which channel produced
  **follows**, not plays, and cut the ones that didn't.

---

## What actually moves listener numbers

Ranked by what works for an independent artist with no budget:

1. **Playlist placement.** Slow, compounding, and the only thing here that keeps working
   after you stop posting. Pitch relentlessly.
2. **One good piece of video.** A single clip that travels beats thirty posts that don't.
   Invest in one shoot, not thirty.
3. **Consistent presence.** Same cadence, same voice, every week. Audience compounds on
   predictability.
4. **Real collaboration.** A feature with another artist multiplies both audiences. Better
   than any amount of your own cross-posting.
5. **Email list.** Small but it converts. Never sell it.

Things that do *not* work: volume posting, buying plays, and posting the same asset on
every platform with the same caption.

## A note on the analytics tab

Record plays, likes and reposts **once a week, same day, same time.** The tool computes
real deltas from what you enter. It cannot fetch those numbers for you — SoundCloud has no
public endpoint for them, and track pages rate-limit unauthenticated requests, which is
why the input form exists rather than an auto-sync.

Real numbers over a few weeks will tell you which track is actually working. Three of your
five were uploaded recently, so the catalogue is young — give it a month before drawing
conclusions.