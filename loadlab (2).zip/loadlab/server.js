// language: javascript, file: server.js, runtime: Node 24+, target: localhost
// LoadLab entry point. Loopback by default: this runs load engines against targets you
// control and stores your analytics. Pass --host 0.0.0.0 only if you understand that
// anyone who can reach the port can start load runs on your machine.
'use strict';

const path = require('node:path');
const { parseArgs } = require('node:util');

const { Db } = require('./src/db');
const { Api, createServer } = require('./src/api');

const { values: v } = parseArgs({
  options: {
    port: { type: 'string', default: process.env.PORT || '8080' },
    host: { type: 'string', default: '127.0.0.1' },
    db: { type: 'string', default: path.join(__dirname, 'data', 'loadlab.db') },
    help: { type: 'boolean', default: false },
  },
});

if (v.help) {
  process.stdout.write(
    'LoadLab server\n\n' +
      '  --port <n>    listen port (default 8080, or $PORT)\n' +
      '  --host <a>    bind address (default 127.0.0.1 - loopback only)\n' +
      '  --db <path>   sqlite file (default ./data/loadlab.db)\n'
  );
  process.exit(0);
}

const db = new Db(v.db);
const api = new Api(db);
const server = createServer(api);

const HOST = v.host;
const PORT = Number(v.port);

// Schedule cadence: cheap poll, guarded so it cannot overlap itself.
const ticker = setInterval(() => {
  try {
    api.tickSchedules();
  } catch (e) {
    console.error('scheduler tick failed:', e.message);
  }
}, 30000);
ticker.unref();

server.listen(PORT, HOST, () => {
  const exposure = HOST === '127.0.0.1' ? 'loopback only (this machine)' : `ALL INTERFACES (${HOST})`;
  console.log(`LoadLab  http://${HOST}:${PORT}`);
  console.log(`  exposure: ${exposure}`);
  console.log(`  database: ${v.db}`);
  console.log(`  targets: ${api.listTargets().length}  runs: ${api.listRuns(500).length}  tracks: ${api.listTracks().length}`);
  if (HOST !== '127.0.0.1') {
    console.log('\n  WARNING: bound beyond loopback. Anyone who can reach this port can start load runs.');
  }
});

function shutdown(signal) {
  console.log(`\n${signal} - draining`);
  for (const [, e] of api.engines) e.cancel();
  clearInterval(ticker);
  server.close(() => {
    db.close();
    process.exit(0);
  });
  setTimeout(() => {
    db.close();
    process.exit(0);
  }, 8000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));