// language: javascript, file: hardened-proxy.js, runtime: Node 20+, target: Windows/Linux host
// TLS-terminating reverse proxy in front of the mock server.
//
// Hardening delivered:
//   - TLS 1.2 floor, 1.3 preferred, forward-secret suites only
//   - HSTS, CSP, X-Content-Type-Options, frame/referrer lockdown on every response
//   - bearer auth via SHA-256 digest + timingSafeEqual (no length leak, no early exit)
//   - CIDR + single-IP allowlist, checked before any routing work
//   - global rate limit independent of the upstream limiter
//   - request/header/timeouts so a slow client cannot pin a connection
//   - hop-by-hop header stripping, no upstream internals in error bodies
//   - structured JSON audit log, graceful drain on SIGTERM/SIGINT
'use strict';

const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const crypto = require('node:crypto');
const net = require('node:net');
const { parseArgs } = require('node:util');

const { values: v } = parseArgs({
  options: {
    port: { type: 'string', default: '8443' },
    backend: { type: 'string', default: '127.0.0.1:8787' },
    cert: { type: 'string', default: './cert/server.pfx' },
    'cert-pass': { type: 'string', default: '' },
    token: { type: 'string', default: process.env.LOADLAB_TOKEN || '' },
    allow: { type: 'string', default: '127.0.0.1/32,::1/128' },
    'max-conns': { type: 'string', default: '512' },
    'body-limit': { type: 'string', default: '65536' },
    'headers-timeout': { type: 'string', default: '10000' },
    'request-timeout': { type: 'string', default: '20000' },
    'keepalive': { type: 'string', default: '5000' },
    'rate-limit': { type: 'string', default: '300' },
    'rate-window': { type: 'string', default: '60000' },
    log: { type: 'string', default: '' },
    help: { type: 'boolean', default: false },
  },
});

if (v.help) {
  process.stdout.write(
    'hardened-proxy.js [options]\n' +
      '  --port <n>              TLS listen port (default 8443)\n' +
      '  --backend <host:port>   upstream (default 127.0.0.1:8787)\n' +
      '  --cert <pfx>            TLS cert+key PFX (default ./cert/server.pfx)\n' +
      '  --cert-pass <pw>        PFX passphrase\n' +
      '  --token <secret>        bearer token clients must present\n' +
      '  --allow <cidrs>         comma-separated allowlist (default loopback only)\n' +
      '  --max-conns <n>         concurrent connection ceiling (default 512)\n' +
      '  --body-limit <bytes>    max request body (default 65536)\n' +
      '  --headers-timeout <ms>  headers must arrive within (default 10000)\n' +
      '  --request-timeout <ms>  full request ceiling (default 20000)\n' +
      '  --keepalive <ms>        keepalive idle timeout (default 5000)\n' +
      '  --rate-limit <n>        requests per window per IP (default 300)\n' +
      '  --rate-window <ms>      rate window (default 60000)\n' +
      '  --log <path>            append JSON audit log to file\n'
  );
  process.exit(0);
}

const PORT = Number(v.port);
const MAX_CONNS = Number(v['max-conns']);
const BODY_LIMIT = Number(v['body-limit']);
const HEADERS_TIMEOUT = Number(v['headers-timeout']);
const REQUEST_TIMEOUT = Number(v['request-timeout']);
const KEEPALIVE = Number(v.keepalive);
const RATE_LIMIT = Number(v['rate-limit']);
const RATE_WINDOW = Number(v['rate-window']);
const [BACKEND_HOST, BACKEND_PORT] = v.backend.split(':');
const TOKEN = v.token;

if (!TOKEN) {
  console.error('refusing to start without --token (or LOADLAB_TOKEN): an unauthenticated TLS listener is a public service');
  process.exit(1);
}
if (!fs.existsSync(v.cert)) {
  console.error(`TLS cert not found: ${v.cert}\nrun new-cert.ps1 first`);
  process.exit(1);
}

// ---- audit log -----------------------------------------------------------
const logStream = v.log ? fs.createWriteStream(v.log, { flags: 'a' }) : null;
function audit(evt) {
  const line = JSON.stringify({ ts: new Date().toISOString(), ...evt });
  if (logStream) logStream.write(line + '\n');
  if (process.env.LOADLAB_AUDIT_STDOUT !== '0') process.stdout.write(line + '\n');
}

// ---- allowlist -----------------------------------------------------------
function ipToLong(ip) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return ((p[0] << 24) >>> 0) + (p[1] << 16) + (p[2] << 8) + p[3];
}

const allowList = v.allow
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean)
  .map((entry) => {
    const [addr, bitsRaw] = entry.split('/');
    const v6 = addr.includes(':');
    const bits = bitsRaw !== undefined ? Number(bitsRaw) : v6 ? 128 : 32;
    const long = v6 ? null : ipToLong(addr);
    if (!v6 && long === null) {
      console.error(`bad allowlist entry: ${entry}`);
      process.exit(1);
    }
    return { v6, addr: v6 ? addr.toLowerCase() : null, long, bits, raw: entry };
  });

function inAllowlist(ip) {
  const clean = ip.replace(/^::ffff:/, '');
  for (const rule of allowList) {
    if (rule.v6) {
      if (clean.toLowerCase() === rule.addr) return true;
      continue;
    }
    const n = ipToLong(clean);
    if (n === null) continue;
    if (rule.bits === 0) return true;
    const mask = rule.bits === 32 ? 0xffffffff : ~((1 << (32 - rule.bits)) - 1) >>> 0;
    if (((n & mask) >>> 0) === ((rule.long & mask) >>> 0)) return true;
  }
  return false;
}

// ---- per-IP rate limit ---------------------------------------------------
const rateState = new Map(); // ip -> timestamps
setInterval(() => {
  const cutoff = Date.now() - RATE_WINDOW;
  for (const [ip, arr] of rateState) {
    while (arr.length && arr[0] < cutoff) arr.shift();
    if (!arr.length) rateState.delete(ip);
  }
}, 10000).unref();

function rateCheck(ip) {
  const now = Date.now();
  const arr = rateState.get(ip) || [];
  while (arr.length && arr[0] < now - RATE_WINDOW) arr.shift();
  if (arr.length >= RATE_LIMIT) {
    rateState.set(ip, arr);
    return Math.ceil((arr[0] + RATE_WINDOW - now) / 1000);
  }
  arr.push(now);
  rateState.set(ip, arr);
  return 0;
}

// ---- responses -----------------------------------------------------------
const SECURITY_HEADERS = {
  'strict-transport-security': 'max-age=63072000; includeSubDomains; preload',
  'content-security-policy': "default-src 'none'; frame-ancestors 'none'",
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'no-referrer',
  'cross-origin-opener-policy': 'same-origin',
  'cross-origin-resource-policy': 'same-origin',
  'permissions-policy': 'geolocation=(), camera=(), microphone=()',
};

function fail(res, status, code) {
  // Deliberately terse: an error body is attacker-visible surface.
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  });
  res.end(JSON.stringify({ error: code }));
}

const TOKEN_DIGEST = crypto.createHash('sha256').update(TOKEN).digest();
function authOk(req) {
  const presented = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!presented) return false;
  const digest = crypto.createHash('sha256').update(presented).digest();
  // Fixed-length digests: timingSafeEqual never short-circuits on content.
  return crypto.timingSafeEqual(digest, TOKEN_DIGEST);
}

const HOP_BY_HOP = new Set([
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'trailers', 'transfer-encoding', 'upgrade',
]);

function proxyReq(req, res, clientIp) {
  const opts = {
    host: BACKEND_HOST,
    port: Number(BACKEND_PORT),
    method: req.method,
    path: req.url,
    headers: { host: `${BACKEND_HOST}:${BACKEND_PORT}` },
    rejectUnauthorized: false,
  };

  for (const [k, val] of Object.entries(req.headers)) {
    const key = k.toLowerCase();
    if (HOP_BY_HOP.has(key)) continue;
    if (key === 'authorization') continue; // terminate auth here, never forward
    if (key === 'cookie') continue;
    opts.headers[key] = val;
  }
  opts.headers['x-forwarded-for'] = clientIp;
  opts.headers['x-forwarded-proto'] = 'https';
  opts.headers['x-forwarded-host'] = req.headers.host || '';

  let bodyBytes = 0;
  const upstream = http.request(opts, (upRes) => {
    const headers = {};
    for (const [k, val] of Object.entries(upRes.headers)) {
      const key = k.toLowerCase();
      if (HOP_BY_HOP.has(key)) continue;
      if (key === 'server') continue; // do not leak upstream identity
      headers[key] = val;
    }
    Object.assign(headers, SECURITY_HEADERS);
    res.writeHead(upRes.statusCode, headers);
    upRes.pipe(res);
  });

  upstream.setTimeout(REQUEST_TIMEOUT, () => upstream.destroy(new Error('upstream timeout')));

  upstream.on('error', (e) => {
    audit({ evt: 'upstream_error', ip: clientIp, path: req.url, msg: e.message });
    if (!res.headersSent) fail(res, 502, 'bad_gateway');
    else res.destroy();
  });

  req.on('data', (chunk) => {
    bodyBytes += chunk.length;
    if (bodyBytes > BODY_LIMIT) {
      upstream.destroy();
      audit({ evt: 'body_limit', ip: clientIp, path: req.url, limit: BODY_LIMIT });
      if (!res.headersSent) fail(res, 413, 'payload_too_large');
    } else {
      upstream.write(chunk);
    }
  });
  req.on('end', () => upstream.end());
}

const server = https.createServer(
  {
    pfx: fs.readFileSync(v.cert),
    passphrase: v['cert-pass'] || undefined,
    minVersion: 'TLSv1.2',
    maxVersion: 'TLSv1.3',
    honorCipherOrder: true,
    ciphers: [
      'TLS_AES_256_GCM_SHA384',
      'TLS_CHACHA20_POLY1305_SHA256',
      'ECDHE-ECDSA-AES256-GCM-SHA384',
      'ECDHE-RSA-AES256-GCM-SHA384',
      'ECDHE-ECDSA-CHACHA20-POLY1305',
      'ECDHE-RSA-CHACHA20-POLY1305',
      'ECDHE-ECDSA-AES128-GCM-SHA256',
      'ECDHE-RSA-AES128-GCM-SHA256',
    ].join(':'),
  },
  (req, res) => {
    const clientIp = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    const started = Date.now();

    res.on('finish', () => {
      audit({
        evt: 'request',
        ip: clientIp,
        method: req.method,
        path: req.url,
        status: res.statusCode,
        ms: Date.now() - started,
        tls: req.socket.getProtocol ? req.socket.getProtocol() : null,
      });
    });

    if (!inAllowlist(clientIp)) {
      audit({ evt: 'denied_allowlist', ip: clientIp, path: req.url });
      return fail(res, 403, 'forbidden');
    }
    if (!authOk(req)) {
      audit({ evt: 'denied_auth', ip: clientIp, path: req.url });
      return fail(res, 401, 'unauthorized');
    }
    const retry = rateCheck(clientIp);
    if (retry > 0) {
      audit({ evt: 'denied_rate', ip: clientIp, path: req.url });
      res.setHeader?.('retry-after', String(retry));
      return fail(res, 429, 'rate_limited');
    }
    return proxyReq(req, res, clientIp);
  }
);

server.maxConnections = MAX_CONNS;
server.headersTimeout = HEADERS_TIMEOUT;
server.requestTimeout = REQUEST_TIMEOUT;
server.keepAliveTimeout = KEEPALIVE;
server.on('tlsClientError', (err) => audit({ evt: 'tls_error', msg: err.message }));

function shutdown(signal) {
  audit({ evt: 'shutdown', signal });
  server.close(() => {
    if (logStream) logStream.end();
    process.exit(0);
  });
  // Sockets held open by keepalive would otherwise stall close() indefinitely.
  setTimeout(() => process.exit(0), 8000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

server.listen(PORT, '0.0.0.0', () => {
  audit({ evt: 'listening', port: PORT, backend: v.backend, allow: v.allow });
  process.stdout.write(
    `hardened-proxy  https://0.0.0.0:${PORT}  ->  http://${v.backend}\n` +
      `  tls: 1.2 floor / 1.3 preferred, PFS suites\n` +
      `  auth: bearer required | allowlist: ${v.allow}\n` +
      `  limits: ${MAX_CONNS} conns, ${BODY_LIMIT}B body, ${HEADERS_TIMEOUT}ms headers, ${REQUEST_TIMEOUT}ms request\n` +
      `  rate: ${RATE_LIMIT} req / ${RATE_WINDOW}ms per IP\n` +
      '  client must trust the cert - see trust-cert.ps1, or pass --ca to loadtest.js\n'
  );
});