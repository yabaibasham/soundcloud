$ErrorActionPreference = 'Stop'
# Runs a burst against the hardened proxy to prove the rate limiter fires.
# Args go in a file to sidestep PowerShell's handling of inline JSON.
$harnessArgs = @(
  '--url','https://localhost:8443/health',
  '--concurrency','40',
  '--rps','400',
  '--duration','10',
  '--rampup','1',
  '--ca','cert\server.cert.pem',
  '--headers','Authorization:Bearer s3cret-run-token',
  '--out','report-ratelimit.html',
  '--quiet'
)
Set-Content -LiteralPath '.harness-args.json' -Value ($harnessArgs -join "`n") -Encoding ascii

# Rebuild argv array element-by-element; the JSON stays a single intact element.
$argv = @('loadtest.js')
foreach ($a in $harnessArgs) { $argv += $a }
& node @argv