# language: powershell, file: new-cert.ps1, runtime: PowerShell 5.1+, target: Windows 10/11
# Mints a self-signed TLS cert for the hardened proxy and exports it as PFX + PEM.
# Run once. Output: cert/server.pfx, cert/server.key.pem, cert/server.cert.pem
param(
  [string]$DnsName = 'localhost',
  [string]$OutDir = 'cert',
  [string]$PfxPassword = '',
[int]$ValidDays = 365,
  [string[]]$Sans = @(),
  [switch]$NoPassword
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not (Test-Path -LiteralPath $OutDir)) {
  New-Item -ItemType Directory -Path $OutDir | Out-Null
}

# SANs: PS 5.1's New-SelfSignedCertificate wants bare names/IPs here. Passing
# "DNS:"/"IP:" prefixes stores them as literal DNS strings, which then fails
# hostname validation with SEC_E_WRONG_PRINCIPAL.
$sanNames = @('localhost', '127.0.0.1') + $Sans
Write-Host "certificate subject : CN=$DnsName"
Write-Host "subject alt names   : $($sanNames -join ', ')"

$cert = New-SelfSignedCertificate `
  -Subject "CN=$DnsName" `
  -DnsName $sanNames `
  -CertStoreLocation 'Cert:\CurrentUser\My' `
  -KeyExportPolicy Exportable `
  -KeyLength 4096 `
  -HashAlgorithm SHA384 `
  -NotAfter (Get-Date).AddDays($ValidDays) `
  -KeyUsage DigitalSignature, KeyEncipherment `
  -TextExtension @('2.5.29.19 = {text}1.3.6.1.5.5.7.3.1', '2.5.29.37 = {text}1.3.6.1.5.5.7.3.1')

$pfxPath = Join-Path $OutDir 'server.pfx'
$keyPath = Join-Path $OutDir 'server.key.pem'
$crtPath = Join-Path $OutDir 'server.cert.pem'

if ($PfxPassword) {
  Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password (ConvertTo-SecureString $PfxPassword -AsPlainText -Force) | Out-Null
} elseif ($NoPassword) {
  Export-PfxCertificate -Cert $cert -FilePath $pfxPath | Out-Null
} else {
  $PfxPassword = Read-Host 'PFX passphrase (blank for none)'
  if ($PfxPassword) {
    Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password (ConvertTo-SecureString $PfxPassword -AsPlainText -Force) | Out-Null
  } else {
    Export-PfxCertificate -Cert $cert -FilePath $pfxPath | Out-Null
  }
}

# .NET Framework (PS 5.1) has no PKCS#8 exporter. The PFX above is what the proxy
# consumes, so PEM key export is best-effort and its absence is not fatal.
try {
  $rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
  $der = $rsa.ExportRSAPrivateKey()
  $pemKey = "-----BEGIN RSA PRIVATE KEY-----`n" + [Convert]::ToBase64String($der, 'InsertLineBreaks') + "`n-----END RSA PRIVATE KEY-----`n"
  Set-Content -LiteralPath $keyPath -Value $pemKey -NoNewline -Encoding ascii
  $keyNote = 'written'
} catch {
  $keyNote = 'SKIPPED (no PKCS#8/RSA export on this runtime - the PFX has the key; openssl not required)'
}

$pemCrt = "-----BEGIN CERTIFICATE-----`n" + [Convert]::ToBase64String($cert.RawData, 'InsertLineBreaks') + "`n-----END CERTIFICATE-----`n"
Set-Content -LiteralPath $crtPath -Value $pemCrt -NoNewline -Encoding ascii

Write-Host ""
Write-Host "written:"
Write-Host "  $pfxPath   (server cert + key, for hardened-proxy.js --cert)"
Write-Host "  $crtPath   (public cert only - safe to share as the client trust anchor)"
Write-Host "  $keyPath   (private key PEM - do not share) [$keyNote]"
Write-Host ""
if (-not $PfxPassword) {
  Write-Host 'NOTE: PFX has a blank passphrase. Set one with -PfxPassword <pw>.'
  Write-Host ''
}
Write-Host "thumbprint : $($cert.Thumbprint)"
Write-Host "expires    : $($cert.NotAfter.ToString('yyyy-MM-dd'))"
Write-Host "store      : Cert:\CurrentUser\My (remove with: Remove-Item 'Cert:\CurrentUser\My\$($cert.Thumbprint)')"
Write-Host ""
Write-Host "next: run trust-cert.ps1 to trust it on this machine, then start the proxy"