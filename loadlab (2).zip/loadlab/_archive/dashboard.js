// language: javascript, file: dashboard.js, runtime: Node 20+, target: localhost browser UI
// Local control panel for loadtest.js. Serves a single-page UI and shells out to
// the harness, streaming its result JSON back. Loopback-only by default: this spawns
// a load generator, so it must not be reachable from the network.
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { spawn } = require('node:child_process');
const { parseArgs } = require('node:util');

const { values: v } = parseArgs({
  options: {
    port: { type: 'string', default: '8788' },
    host: { type: 'string', default: '127.0.0.1' },
    harness: { type: 'string', default: './loadtest.js' },
    ca: { type: 'string', default: '' },
    help: { type: 'boolean', default: false },
  },
});

if (v.help) {
  process.stdout.write(
    'dashboard.js [options]\n' +
      '  --port <n>      listen port (default 8788)\n' +
      '  --host <addr>   bind address (default 127.0.0.1 - keep it that way)\n' +
      '  --harness <p>   path to loadtest.js (default ./loadtest.js)\n' +
      '  --ca <path>     PEM for TLS targets, forwarded to the harness\n'
  );
  process.exit(0);
}

const PORT = Number(v.port);
const HOST = v.host;
const HARNESS = path.resolve(v.harness);
const RUNS_DIR = path.join(__dirname, '.runs');

if (!fs.existsSync(RUNS_DIR)) fs.mkdirSync(RUNS_DIR, { recursive: true });

let running = false;
let current = null;

function send(res, status, type, body) {
  res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 1e6) reject(new Error('body too large'));
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

async function handleRun(req, res) {
  if (running) return send(res, 409, 'application/json', JSON.stringify({ error: 'a run is already in progress' }));

  let cfg;
  try {
    cfg = JSON.parse(await readBody(req));
  } catch (e) {
    return send(res, 400, 'application/json', JSON.stringify({ error: e.message }));
  }

  const url = String(cfg.url || '').trim();
  if (!/^https?:\/\//i.test(url)) {
    return send(res, 400, 'application/json', JSON.stringify({ error: 'url must start with http:// or https://' }));
  }

  const num = (x, lo, hi, dflt) => {
    const n = Number(x);
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
  };

  const concurrency = num(cfg.concurrency, 1, 500, 40);
  const duration = num(cfg.duration, 1, 3600, 15);
  const rps = num(cfg.rps, 0, 100000, 0);
  const rampup = num(cfg.rampup, 0, 300, 2);
  const transport = cfg.transport === 'browser' ? 'browser' : 'http';
  const headers = String(cfg.headers || '').trim();

  const stamp = Date.now();
  const outBase = path.join(RUNS_DIR, `run-${stamp}`);

  const args = [
    HARNESS,
    '--url', url,
    '--concurrency', String(concurrency),
    '--duration', String(duration),
    '--rampup', String(rampup),
    '--rps', String(rps),
    '--transport', transport,
    '--out', `${outBase}.html`,
    '--json',
    '--quiet',
  ];
  if (headers) args.push('--headers', headers);
  if (v.ca) args.push('--ca', v.ca);

  running = true;
  const startedAt = Date.now();
  current = { startedAt, cfg: { url, concurrency, duration, rps, rampup, transport, headers } };

  const child = spawn(process.execPath, args, {
    cwd: __dirname,
    env: v.ca ? { ...process.env, NODE_EXTRA_CA_CERTS: path.resolve(v.ca) } : process.env,
  });

  let stdout = '';
  let stderr = '';
  child.stdout.on('data', (c) => (stdout += c));
  child.stderr.on('data', (c) => (stderr += c));

  child.on('close', (code) => {
    running = false;
    const elapsed = ((Date.now() - startedAt) / 1000).toFixed(1);
    let result = null;
    const jsonPath = `${outBase}.json`;
    if (fs.existsSync(jsonPath)) {
      try {
        result = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
      } catch (e) {
        stderr += `\nfailed to parse result json: ${e.message}`;
      }
    }
    const payload = {
      ok: code === 0 && result !== null,
      exitCode: code,
      elapsedSeconds: Number(elapsed),
      reportFile: fs.existsSync(`${outBase}.html`) ? `${outBase}.html` : null,
      result,
      error: code !== 0 ? (stderr.trim().split('\n').slice(-4).join('\n') || `harness exited ${code}`) : null,
    };
    fs.writeFileSync(`${outBase}.result.json`, JSON.stringify(payload, null, 2));
    console.log(`[dashboard] run finished in ${elapsed}s exit=${code} -> ${payload.reportFile || 'no report'}`);

    if (!res.writableEnded) {
      send(res, payload.ok ? 200 : 500, 'application/json', JSON.stringify(payload));
    }
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  if (req.method === 'POST' && url.pathname === '/api/run') return handleRun(req, res);

  if (req.method === 'GET' && url.pathname === '/api/status') {
    const runs = fs
      .readdirSync(RUNS_DIR)
      .filter((f) => f.endsWith('.result.json'))
      .sort()
      .slice(-10)
      .reverse()
      .map((f) => {
        try {
          const d = JSON.parse(fs.readFileSync(path.join(RUNS_DIR, f), 'utf8'));
          return { file: f, ok: d.ok, at: d.elapsedSeconds, total: d.result ? d.result.total : 0, url: d.result ? d.result.url : null };
        } catch {
          return null;
        }
      })
      .filter(Boolean);
    return send(res, 200, 'application/json', JSON.stringify({ running, runs }));
  }

  if (req.method === 'GET' && url.pathname.startsWith('/.runs/')) {
    // Confine reads to .runs and block traversal out of it.
    const name = path.basename(url.pathname);
    const file = path.join(RUNS_DIR, name);
    if (!file.startsWith(RUNS_DIR) || !fs.existsSync(file)) {
      return send(res, 404, 'application/json', JSON.stringify({ error: 'not_found' }));
    }
    const type = name.endsWith('.html') ? 'text/html; charset=utf-8'
      : name.endsWith('.json') ? 'application/json' : 'text/plain';
    return send(res, 200, type, fs.readFileSync(file));
  }

  if (req.method === 'GET' && url.pathname === '/') {
    return send(res, 200, 'text/html; charset=utf-8', DASHBOARD_HTML);
  }

  send(res, 404, 'application/json', JSON.stringify({ error: 'not_found', route: `${req.method} ${url.pathname}` }));
});

const DASHBOARD_HTML = fs.readFileSync(path.join(__dirname, 'dashboard.html'), 'utf8');

server.listen(PORT, HOST, () => {
  console.log(`dashboard  http://${HOST}:${PORT}`);
  console.log(`  harness: ${HARNESS}`);
  console.log(`  runs:    ${RUNS_DIR}`);
  if (HOST !== '127.0.0.1' && HOST !== 'localhost') {
    console.log('\n  WARNING: bound beyond loopback. This spawns a load generator - keep it local.');
  }
});