// language: javascript, file: sc-dashboard.js, runtime: Node 20+, target: localhost browser UI
// Web view for sc-data. Read-only over the JSON the CLI writes, plus a form to
// record new manual entries. Loopback only: it serves your data, nothing else.
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { parseArgs } = require('node:util');

const { values: v } = parseArgs({
  options: { port: { type: 'string', default: '8789' }, host: { type: 'string', default: '127.0.0.1' } },
});

const PORT = Number(v.port);
const HOST = v.host;
const DATA = path.join(__dirname, 'sc-data');

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')); } catch { return fallback; }
}

function send(res, status, type, body) {
  res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => { d += c; if (d.length > 1e6) reject(new Error('too large')); });
    req.on('end', () => resolve(d));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  if (req.method === 'GET' && url.pathname === '/api/data') {
    const tracks = readJson('tracks.json', []);
    const history = readJson('history.json', []);
    const byTrack = {};
    for (const t of tracks) {
      const rows = history.filter((h) => h.id === t.id);
      const meta = [...rows].reverse().find((r) => r.title);
      const manual = rows.filter((r) => r.manual).map((r) => ({ at: r.at, ...r.manual, note: r.note }));
      byTrack[t.id] = {
        id: t.id, url: t.url,
        title: meta ? meta.title : null,
        artwork: meta ? meta.artwork : null,
        soundcloudTrackId: meta ? meta.soundcloudTrackId : null,
        snapshots: rows.filter((r) => !r.manual).length,
        manual,
      };
    }
    return send(res, 200, 'application/json', JSON.stringify({ generatedAt: new Date().toISOString(), tracks: byTrack }));
  }

  if (req.method === 'POST' && url.pathname === '/api/record') {
    let body;
    try { body = JSON.parse(await readBody(req)); } catch (e) { return send(res, 400, 'application/json', JSON.stringify({ error: e.message })); }
    const id = String(body.id || '').trim();
    if (!/^[^/]+\/[^/]+$/.test(id)) return send(res, 400, 'application/json', JSON.stringify({ error: 'id must look like user/track' }));
    const entry = { at: new Date().toISOString(), id, url: `https://soundcloud.com/${id}`, manual: {}, note: body.note || null };
    let bad = null;
    for (const k of ['plays', 'likes', 'reposts', 'comments']) {
      if (body[k] !== '' && body[k] != null) {
        const n = Number(body[k]);
        if (!Number.isFinite(n) || n < 0) bad = `${k} must be a non-negative number`;
        entry.manual[k] = Math.round(n);
      }
    }
    if (bad) return send(res, 400, 'application/json', JSON.stringify({ error: bad }));
    if (!Object.keys(entry.manual).length) return send(res, 400, 'application/json', JSON.stringify({ error: 'enter at least one number' }));

    const history = readJson('history.json', []);
    history.push(entry);
    fs.writeFileSync(path.join(DATA, 'history.json'), JSON.stringify(history, null, 2));
    return send(res, 200, 'application/json', JSON.stringify({ ok: true, entry }));
  }

  if (req.method === 'GET' && url.pathname === '/') return send(res, 200, 'text/html; charset=utf-8', HTML);
  send(res, 404, 'application/json', JSON.stringify({ error: 'not_found', route: `${req.method} ${url.pathname}` }));
});

const HTML = fs.readFileSync(path.join(__dirname, 'sc-dashboard.html'), 'utf8');

server.listen(PORT, HOST, () => {
  console.log(`sc-dashboard  http://${HOST}:${PORT}`);
  if (HOST !== '127.0.0.1') console.log('  WARNING: bound beyond loopback; this serves your local data.');
});