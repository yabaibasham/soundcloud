// language: javascript, file: sc-stats.js, runtime: Node 20+, target: local analytics
// SoundCloud track analytics. Two independent sources, both legitimate:
//
//  1. oEmbed (automatic)  - title, author, artwork, track ID. No auth. No play counts.
//  2. manual entry        - you read numbers from your own SoundCloud dashboard and
//                           record them; the tool charts the real growth curve.
//
// Usage:
//   node sc-stats.js snapshot            pull oEmbed for every tracked track
//   node sc-stats.js add <url>          track a new SoundCloud URL
//   node sc-stats.js list               show tracked tracks + latest snapshot
//   node sc-stats.js record <id> plays=<n> likes=<n> reposts=<n> [note]
//   node sc-stats.js report             print the growth table
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { parseArgs } = require('node:util');

const { values: v, positionals } = parseArgs({ allowPositionals: true, options: {} });

const DATA_DIR = path.join(__dirname, 'sc-data');
const TRACKS_FILE = path.join(DATA_DIR, 'tracks.json');
const HISTORY_FILE = path.join(DATA_DIR, 'history.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

const DEFAULT_TRACKS = [
  'https://soundcloud.com/basham_x/demons-and-daemons',
  'https://soundcloud.com/basham_x/velvet-damage-basham',
  'https://soundcloud.com/basham_x/rainy-days-basham',
  'https://soundcloud.com/basham_x/see-me-on-my-grind-basham',
  'https://soundcloud.com/basham_x/wild-fire-basham',
];

function loadTracks() {
  const t = readJson(TRACKS_FILE, null);
  if (t && t.length) return t;
  const seeded = DEFAULT_TRACKS.map((url) => ({ url, id: trackIdFromUrl(url), added: new Date().toISOString() }));
  writeJson(TRACKS_FILE, seeded);
  return seeded;
}

function trackIdFromUrl(url) {
  const m = url.match(/soundcloud\.com\/([^/]+)\/([^/?#]+)/i);
  return m ? `${m[1]}/${m[2]}` : url;
}

async function fetchOembed(url) {
  const endpoint = `https://soundcloud.com/oembed?url=${encodeURIComponent(url)}&format=json`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 20000);
  try {
    const res = await fetch(endpoint, {
      signal: ctrl.signal,
      headers: { 'user-agent': 'LoadLab/1.0 (local personal analytics)' },
    });
    if (!res.ok) return { error: `HTTP ${res.status}` };
    const j = await res.json();
    const trackId = (j.html || '').match(/tracks%2F(\d+)/)?.[1] || (j.html || '').match(/tracks\/(\d+)/)?.[1] || null;
    return {
      title: j.title || null,
      author: j.author_name || null,
      authorUrl: j.author_url || null,
      artwork: j.thumbnail_url || null,
      soundcloudTrackId: trackId,
    };
  } catch (e) {
    return { error: e.name === 'AbortError' ? 'timeout' : e.message };
  } finally {
    clearTimeout(timer);
  }
}

async function cmdSnapshot() {
  const tracks = loadTracks();
  const history = readJson(HISTORY_FILE, []);
  const stamp = new Date().toISOString();

  console.log(`snapshotting ${tracks.length} tracks via oEmbed\n`);
  const entries = [];
  for (const t of tracks) {
    process.stdout.write(`  ${t.id} ... `);
    const meta = await fetchOembed(t.url);
    if (meta.error) {
      console.log(`SKIPPED (${meta.error})`);
      console.log('    oEmbed has no rate limit documented; if you see repeated errors, wait a minute.');
      continue;
    }
    entries.push({ at: stamp, id: t.id, url: t.url, ...meta, manual: null });
    console.log(meta.title || '(untitled)');
    await new Promise((r) => setTimeout(r, 800)); // be polite to a free public endpoint
  }

  history.push(...entries);
  writeJson(HISTORY_FILE, history);
  console.log(`\n${entries.length} snapshot(s) recorded -> ${HISTORY_FILE}`);
  console.log('note: oEmbed exposes no play/like/repost counts. Use "record" with numbers from your dashboard.');
}

function cmdAdd(url) {
  if (!url || !/^https?:\/\//i.test(url)) {
    console.error('usage: node sc-stats.js add https://soundcloud.com/user/track');
    process.exit(1);
  }
  const tracks = loadTracks();
  const id = trackIdFromUrl(url);
  if (tracks.some((t) => t.id === id)) {
    console.log(`already tracked: ${id}`);
    return;
  }
  tracks.push({ url, id, added: new Date().toISOString() });
  writeJson(TRACKS_FILE, tracks);
  console.log(`tracking: ${id}`);
}

function cmdList() {
  const tracks = loadTracks();
  const history = readJson(HISTORY_FILE, []);
  console.log(`\n${tracks.length} tracked:\n`);
  for (const t of tracks) {
    const snaps = history.filter((h) => h.id === t.id);
    const latest = snaps[snaps.length - 1];
    const plays = latest && latest.manual ? `plays=${latest.manual.plays}` : 'plays=not recorded';
    console.log(`  ${t.id}`);
    console.log(`    ${latest ? latest.title || '(no title yet)' : '(no snapshot - run "snapshot")'}`);
    console.log(`    ${plays}`);
  }
}

function cmdRecord(args) {
  const id = args[0];
  if (!id) {
    console.error("usage: node sc-stats.js record <user/track> plays=123 likes=4 reposts=2 note=\"...\"");
    process.exit(1);
  }
  const manual = {};
  let note = '';
  for (const a of args.slice(1)) {
    const m = a.match(/^(plays|likes|reposts|comments)=(\d+)$/i);
    if (m) manual[m[1].toLowerCase()] = Number(m[2]);
    if (a.startsWith('note=')) note = a.slice(5).replace(/^"|"$/g, '');
  }
  if (!Object.keys(manual).length) {
    console.error('need at least one of plays= likes= reposts= comments=');
    process.exit(1);
  }

  const history = readJson(HISTORY_FILE, []);
  history.push({
    at: new Date().toISOString(),
    id,
    url: `https://soundcloud.com/${id}`,
    title: null,
    manual,
    note: note || null,
  });
  writeJson(HISTORY_FILE, history);
  console.log(`recorded for ${id}: ${JSON.stringify(manual)}`);
}

function cmdReport() {
  const history = readJson(HISTORY_FILE, []);
  const tracks = loadTracks();
  if (!history.length) {
    console.log('no data yet. run: node sc-stats.js snapshot');
    return;
  }

  const byTrack = new Map();
  for (const h of history) {
    if (!byTrack.has(h.id)) byTrack.set(h.id, []);
    byTrack.get(h.id).push(h);
  }

  console.log('\n  TRACK GROWTH (from recorded entries)\n');
  for (const t of tracks) {
    const rows = (byTrack.get(t.id) || []).filter((h) => h.manual);
    if (!rows.length) {
      console.log(`  ${t.id}\n    no manual entries yet\n`);
      continue;
    }
    const first = rows[0];
    const last = rows[rows.length - 1];
    const d = (k) => (last.manual[k] || 0) - (first.manual[k] || 0);
    console.log(`  ${t.id}`);
    console.log(`    ${last.title || first.title || ''}`);
    console.log(`    plays  ${first.manual.plays ?? '?'} -> ${last.manual.plays ?? '?'}  (${d('plays') >= 0 ? '+' : ''}${d('plays')})`);
    if (last.manual.likes != null) console.log(`    likes  ${first.manual.likes ?? '?'} -> ${last.manual.likes ?? '?'}  (${d('likes') >= 0 ? '+' : ''}${d('likes')})`);
    if (last.manual.reposts != null) console.log(`    reposts ${first.manual.reposts ?? '?'} -> ${last.manual.reposts ?? '?'}  (${d('reposts') >= 0 ? '+' : ''}${d('reposts')})`);
    const hours = (new Date(last.at) - new Date(first.at)) / 36e5;
    if (hours > 0 && d('plays') > 0) console.log(`    rate   ${(d('plays') / hours).toFixed(1)} plays/hour over ${hours.toFixed(1)}h`);
    console.log('');
  }

  const summary = { at: new Date().toISOString(), total: {}, perTrack: {} };
  for (const [id, rows] of byTrack) {
    const manual = rows.filter((h) => h.manual);
    if (!manual.length) continue;
    const last = manual[manual.length - 1].manual;
    summary.perTrack[id] = { title: rows[rows.length - 1].title, ...last };
    for (const k of ['plays', 'likes', 'reposts']) {
      if (last[k] != null) summary.total[k] = (summary.total[k] || 0) + last[k];
    }
  }
  fs.writeFileSync(path.join(DATA_DIR, 'summary.json'), JSON.stringify(summary, null, 2));
  console.log(`  TOTAL across ${Object.keys(summary.perTrack).length} tracks: ${JSON.stringify(summary.total)}`);
}

async function main() {
  const cmd = positionals[0];
  switch (cmd) {
    case 'snapshot': return cmdSnapshot();
    case 'add': return cmdAdd(positionals[1]);
    case 'list': return cmdList();
    case 'record': return cmdRecord(positionals.slice(1));
    case 'report': return cmdReport();
    default:
      console.log(
        'sc-stats.js - SoundCloud track analytics (local, no auth)\n\n' +
          '  node sc-stats.js snapshot                          pull oEmbed metadata for all tracked tracks\n' +
          '  node sc-stats.js add <url>                        track a new SoundCloud URL\n' +
          '  node sc-stats.js list                             show tracks + latest state\n' +
          '  node sc-stats.js record <user/track> plays=123 likes=4 reposts=2\n' +
          '  node sc-stats.js report                           print the growth table\n\n' +
          'oEmbed gives title/author/artwork/track id only. Play, like and repost\n' +
          'counts come from "record", using numbers read from your SoundCloud dashboard.'
      );
  }
}

main().catch((e) => {
  console.error('sc-stats failed:', e.message);
  process.exit(1);
});