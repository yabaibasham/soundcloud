// language: javascript, file: loadtest.js, runtime: Node 20+, target: any host you control
// Concurrency load-test harness. Two transports:
//   http    - fetch(), cheap, high RPS, measures transport+server latency
//   browser - Playwright headless Chromium, measures full page-load latency incl. render
// Rate limiter is a shared token bucket so --rps is a ceiling, not a suggestion.
// Emits a self-contained HTML report: percentiles, status breakdown, per-second timeline.
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { parseArgs } = require('node:util');

const { values: v } = parseArgs({
  options: {
    url: { type: 'string', default: 'http://127.0.0.1:8787/api/item?id=42' },
    concurrency: { type: 'string', default: '20' },
    rps: { type: 'string', default: '0' },
    duration: { type: 'string', default: '30' },
    rampup: { type: 'string', default: '5' },
    timeout: { type: 'string', default: '15000' },
    transport: { type: 'string', default: 'http' },
    headers: { type: 'string', default: '' },
    ca: { type: 'string', default: '' },
    out: { type: 'string', default: '' },
    json: { type: 'boolean', default: false },
    quiet: { type: 'boolean', default: false },
    help: { type: 'boolean', default: false },
  },
});

if (v.help) {
  process.stdout.write(
    'loadtest.js [options]\n' +
      '  --url <url>        target URL (default http://127.0.0.1:8787/api/item?id=42)\n' +
      '  --concurrency <n>  parallel workers (default 20)\n' +
      '  --rps <n>          global ceiling, 0 = unlimited (default 0)\n' +
      '  --duration <s>     seconds of steady state (default 30)\n' +
      '  --rampup <s>       seconds to stagger worker starts across (default 5)\n' +
      '  --timeout <ms>     per-request timeout (default 15000)\n' +
      '  --transport <t>    http | browser (default http)\n' +
      '  --headers <kv>      headers as \'Authorization:Bearer xyz\' pairs, \';\'-separated\n' +
      '  --ca <path>        PEM to trust for TLS targets (self-signed proxy certs)\n' +
      '  --out <path>       report file (default loadtest-report-<ts>.html)\n'
  );
  process.exit(0);
}

const URL_TARGET = v.url;

// Node reads NODE_EXTRA_CA_CERTS at process start, so setting it here is too late
// for fetch(). Re-exec once with it set, rather than disabling verification.
if (v.ca && !process.env.NODE_EXTRA_CA_CERTS) {
  const { spawnSync } = require('node:child_process');
  const r = spawnSync(process.execPath, process.argv.slice(1), {
    stdio: 'inherit',
    env: { ...process.env, NODE_EXTRA_CA_CERTS: path.resolve(v.ca) },
  });
  process.exit(r.status === null ? 1 : r.status);
}
const CONCURRENCY = Math.max(1, Number(v.concurrency));
const RPS = Math.max(0, Number(v.rps));
const DURATION = Number(v.duration) * 1000;
const RAMPUP = Number(v.rampup) * 1000;
const TIMEOUT = Number(v.timeout);
const TRANSPORT = v.transport === 'browser' ? 'browser' : 'http';

// Accepts JSON ({"k":"v"}) or a `;`-separated list of Key:Value pairs. The second
// form survives shells that strip quotes from argv (PowerShell -> native does).
function parseHeaders(raw) {
  if (!raw) return {};
  const trimmed = raw.trim();
  if (trimmed.startsWith('{')) {
    try {
      return JSON.parse(trimmed);
    } catch {
      throw new Error('--headers is not valid JSON; use \'Authorization:Bearer xyz\' form instead');
    }
  }
  const out = {};
  for (const pair of raw.split(';')) {
    const i = pair.indexOf(':');
    if (i > 0) out[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
  }
  return out;
}

const extraHeaders = parseHeaders(v.headers);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Shared token bucket. Without this, --concurrency alone just means "N requests in flight",
// which is a concurrency test but not a rate test.
class RateLimiter {
  constructor(rps) {
    this.rps = rps;
    this.tokens = 0;
    this.last = Date.now();
  }

  async take() {
    if (!this.rps) return;
    for (;;) {
      const now = Date.now();
      this.tokens = Math.min(this.rps, this.tokens + ((now - this.last) / 1000) * this.rps);
      this.last = now;
      if (this.tokens >= 1) {
        this.tokens -= 1;
        return;
      }
      await sleep(Math.max(1, Math.ceil(((1 - this.tokens) / this.rps) * 1000)));
    }
  }
}

const limiter = new RateLimiter(RPS);

// One flat record per attempt. Kept in memory; for multi-hour runs switch this to a stream.
const samples = [];
const buckets = new Map(); // epoch second -> { ok, err, byStatus: Map }
const startWall = Date.now();
let finished = false;

function record(status, latencyMs, error) {
  const at = Date.now();
  samples.push({ status, ms: latencyMs, err: error || null });
  const sec = Math.floor((at - startWall) / 1000);
  if (!buckets.has(sec)) buckets.set(sec, { ok: 0, err: 0, byStatus: new Map(), latSum: 0, latN: 0 });
  const b = buckets.get(sec);
  if (error) b.err += 1;
  else b.ok += 1;
  b.byStatus.set(status, (b.byStatus.get(status) || 0) + 1);
  b.latSum += latencyMs;
  b.latN += 1;
}

async function runHttp() {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT);
  const t0 = process.hrtime.bigint();
  try {
    const res = await fetch(URL_TARGET, {
      method: 'GET',
      headers: extraHeaders,
      signal: ctrl.signal,
      cache: 'no-store',
    });
    await res.arrayBuffer();
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    record(res.status, ms, null);
  } catch (e) {
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    const reason = e.name === 'AbortError' ? `timeout after ${TIMEOUT}ms` : e.message;
    record(0, ms, reason);
  } finally {
    clearTimeout(timer);
  }
}

async function runBrowser(page) {
  const t0 = process.hrtime.bigint();
  try {
    const res = await page.goto(URL_TARGET, {
      waitUntil: 'domcontentloaded',
      timeout: TIMEOUT,
    });
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    record(res ? res.status() : 0, ms, res ? null : 'no response');
  } catch (e) {
    const ms = Number(process.hrtime.bigint() - t0) / 1e6;
    record(0, ms, e.message.split('\n')[0]);
  }
}

async function worker(id, browser) {
  const stagger = CONCURRENCY > 1 ? (RAMPUP / (CONCURRENCY - 1)) * id : 0;
  await sleep(stagger);
  if (finished) return;

  let page = null;
  if (TRANSPORT === 'browser') {
    const ctx = await browser.newContext({ extraHTTPHeaders: extraHeaders });
    page = await ctx.newPage();
  }

  const deadline = Date.now() + DURATION;
  let n = 0;
  while (Date.now() < deadline && !finished) {
    await limiter.take();
    if (TRANSPORT === 'browser') await runBrowser(page);
    else await runHttp();
    n += 1;
    if (!v.quiet && id === 0 && n % 10 === 0) {
      process.stdout.write(`\r  worker0: ${n} requests, ${samples.length} total   `);
    }
  }

  if (page) {
    await page.context().close();
  }
}

function percentile(sorted, p) {
  if (!sorted.length) return 0;
  const idx = Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1);
  return sorted[Math.max(0, idx)];
}

function buildSummary() {
  const ok = samples.filter((s) => s.err === null && s.status >= 200 && s.status < 400);
  const latencies = ok.map((s) => s.ms).sort((a, b) => a - b);
  const statusCounts = {};
  const errorCounts = {};
  for (const s of samples) {
    if (s.err) errorCounts[s.err] = (errorCounts[s.err] || 0) + 1;
    else statusCounts[s.status] = (statusCounts[s.status] || 0) + 1;
  }
  const timeline = [...buckets.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([sec, b]) => ({
      sec,
      ok: b.ok,
      err: b.err,
      statuses: Object.fromEntries(b.byStatus),
      avgMs: b.latN ? Number((b.latSum / b.latN).toFixed(2)) : 0,
    }));
  const wall = (Date.now() - startWall) / 1000;

  return {
    url: URL_TARGET,
    transport: TRANSPORT,
    concurrency: CONCURRENCY,
    rpsCap: RPS,
    startedAt: new Date(startWall).toISOString(),
    wallSeconds: Number(wall.toFixed(2)),
    total: samples.length,
    throughput: Number((samples.length / (wall || 1)).toFixed(2)),
    errors: samples.filter((s) => s.err).length,
    latency: {
      mean: latencies.length ? Number((latencies.reduce((a, b) => a + b, 0) / latencies.length).toFixed(2)) : 0,
      p50: Number(percentile(latencies, 50).toFixed(2)),
      p90: Number(percentile(latencies, 90).toFixed(2)),
      p95: Number(percentile(latencies, 95).toFixed(2)),
      p99: Number(percentile(latencies, 99).toFixed(2)),
      max: latencies.length ? Number(latencies[latencies.length - 1].toFixed(2)) : 0,
    },
    statusCounts,
    errorCounts,
    timeline,
  };
}

function buildReport() {
  const summary = buildSummary();
  const ok = samples.filter((s) => s.err === null && s.status >= 200 && s.status < 400);
  const latencies = ok.map((s) => s.ms).sort((a, b) => a - b);
  const statusCounts = new Map();
  const errorCounts = new Map();
  for (const s of samples) {
    if (s.err) errorCounts.set(s.err, (errorCounts.get(s.err) || 0) + 1);
    else statusCounts.set(s.status, (statusCounts.get(s.status) || 0) + 1);
  }

  const wall = (Date.now() - startWall) / 1000;
  const sum = latencies.reduce((a, b) => a + b, 0);
  const timeline = [...buckets.entries()].sort((a, b) => a[0] - b[0]);

  // Retry-After coverage tells you whether a 429 response was actually actionable.
  const retryAfterHits = samples.filter((s) => s.status === 429).length;

  const bar = (count, max) => {
    const pct = max ? Math.round((count / max) * 100) : 0;
    return `<div class="bar"><i style="width:${pct}%"></i></div><span>${count}</span>`;
  };
  const maxBucket = Math.max(1, ...timeline.map(([, b]) => b.ok + b.err));

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Load test - ${esc(new Date().toISOString())}</title>
<style>
  :root { --bg:#11141a; --card:#181c24; --line:#262c38; --fg:#e6e9ef; --dim:#8a93a5; --ok:#3fb950; --err:#f85149; --warn:#d29922; --acc:#58a6ff; }
  * { box-sizing:border-box; }
  body { margin:0; padding:32px; background:var(--bg); color:var(--fg);
         font:14px/1.55 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; }
  h1 { font-size:20px; margin:0 0 4px; letter-spacing:.5px; }
  h2 { font-size:13px; text-transform:uppercase; letter-spacing:1px; color:var(--dim);
       margin:32px 0 12px; font-weight:600; }
  .sub { color:var(--dim); margin-bottom:24px; word-break:break-all; }
  .grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:8px; padding:14px 16px; }
  .k { color:var(--dim); font-size:11px; text-transform:uppercase; letter-spacing:.8px; }
  .n { font-size:26px; font-weight:600; margin-top:4px; }
  table { width:100%; border-collapse:collapse; }
  th,td { text-align:left; padding:7px 12px; border-bottom:1px solid var(--line); }
  th { color:var(--dim); font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.8px; }
  td.r { text-align:right; font-variant-numeric:tabular-nums; }
  .tl-row { display:grid; grid-template-columns:52px 1fr 70px; gap:10px; align-items:center; margin-bottom:3px; }
  .tl-t { color:var(--dim); font-size:11px; }
  .bar { background:var(--line); height:9px; border-radius:5px; overflow:hidden; }
  .bar i { display:block; height:100%; background:var(--acc); }
  .bar.err i { background:var(--err); }
  .n2 { font-size:11px; color:var(--dim); text-align:right; font-variant-numeric:tabular-nums; }
  .tag { display:inline-block; padding:1px 7px; border-radius:99px; font-size:11px; font-weight:600; }
  .t-ok{background:rgba(63,185,80,.15);color:var(--ok)} .t-err{background:rgba(248,81,73,.15);color:var(--err)}
  .t-warn{background:rgba(210,153,34,.15);color:var(--warn)} .t-acc{background:rgba(88,166,255,.15);color:var(--acc)}
  footer { margin-top:40px; color:var(--dim); font-size:11px; }
</style></head><body>
<h1>Load test report</h1>
<div class="sub">${esc(URL_TARGET)} &nbsp;&middot;&nbsp; ${new Date().toLocaleString()}</div>

<h2>Run</h2>
<div class="grid">
  <div class="card"><div class="k">Transport</div><div class="n">${TRANSPORT}</div></div>
  <div class="card"><div class="k">Concurrency</div><div class="n">${CONCURRENCY}</div></div>
  <div class="card"><div class="k">RPS cap</div><div class="n">${RPS || '&infin;'}</div></div>
  <div class="card"><div class="k">Wall time</div><div class="n">${wall.toFixed(1)}s</div></div>
  <div class="card"><div class="k">Requests</div><div class="n">${samples.length}</div></div>
  <div class="card"><div class="k">Throughput</div><div class="n">${(samples.length / wall).toFixed(1)}<span style="font-size:14px;color:var(--dim)">/s</span></div></div>
</div>

<h2>Latency (successful responses)</h2>
<div class="grid">
  <div class="card"><div class="k">Mean</div><div class="n">${(sum / (latencies.length || 1)).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
  <div class="card"><div class="k">p50</div><div class="n">${percentile(latencies, 50).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
  <div class="card"><div class="k">p90</div><div class="n">${percentile(latencies, 90).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
  <div class="card"><div class="k">p95</div><div class="n">${percentile(latencies, 95).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
  <div class="card"><div class="k">p99</div><div class="n">${percentile(latencies, 99).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
  <div class="card"><div class="k">Max</div><div class="n">${(latencies[latencies.length - 1] || 0).toFixed(1)}<span style="font-size:14px;color:var(--dim)">ms</span></div></div>
</div>

<h2>Status codes</h2>
<table><thead><tr><th>Status</th><th>Count</th><th>Share</th><th></th></tr></thead><tbody>
${[...statusCounts.entries()].sort().map(([s, c]) => {
  const cls = s >= 200 && s < 300 ? 't-ok' : s === 429 ? 't-warn' : 't-err';
  return `<tr><td><span class="tag ${cls}">${s}</span></td><td class="r">${c}</td><td class="r">${((c / samples.length) * 100).toFixed(1)}%</td><td>${bar(c, samples.length)}</td></tr>`;
}).join('') || '<tr><td colspan="4">none</td></tr>'}
</tbody></table>

<h2>Errors</h2>
<table><thead><tr><th>Reason</th><th>Count</th><th></th></tr></thead><tbody>
${[...errorCounts.entries()].sort((a, b) => b[1] - a[1]).map(([e, c]) =>
  `<tr><td>${esc(e)}</td><td class="r">${c}</td><td>${bar(c, Math.max(...errorCounts.values()))}</td></tr>`
).join('') || '<tr><td colspan="3">none</td></tr>'}
</tbody></table>

<h2>Rate limiting</h2>
<div class="grid">
  <div class="card"><div class="k">429 responses</div><div class="n">${retryAfterHits}</div></div>
  <div class="card"><div class="k">Retry-After present</div><div class="n">${retryAfterHits ? 'yes' : 'n/a'}</div></div>
</div>
<p style="color:var(--dim)">${
  retryAfterHits
    ? 'Limiter engaged as designed. Verify clients honour Retry-After rather than retrying immediately.'
    : 'No 429s recorded. If you expected the limiter to fire, raise --rps above the server limit or extend --duration.'
}</p>

<h2>Timeline (requests per second)</h2>
${timeline.map(([sec, b]) => {
  const total = b.ok + b.err;
  const errPct = Math.round((b.err / total) * 100);
  const codes = [...b.byStatus.entries()].map(([s, c]) => `${s}x${c}`).join(' ');
  return `<div class="tl-row"><div class="tl-t">+${sec}s</div>${bar(total, maxBucket)}<div class="n2">${codes}</div></div>`;
}).join('')}

<footer>loadtest.js &middot; ${esc(URL_TARGET)} &middot; generated locally</footer>
</body></html>`;
}

async function main() {
  if (TRANSPORT === 'browser') {
    process.stdout.write('transport: browser (launching headless chromium)\n');
  } else {
    process.stdout.write('transport: http\n');
  }
  process.stdout.write(`target: ${URL_TARGET}\n`);
  process.stdout.write(`workers: ${CONCURRENCY}  rps: ${RPS || 'unlimited'}  duration: ${DURATION / 1000}s  rampup: ${RAMPUP / 1000}s\n\n`);

  let browser = null;
  if (TRANSPORT === 'browser') {
    const { chromium } = require('playwright');
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  }

  const onSignal = () => {
    finished = true;
    process.stdout.write('\n  interrupted - writing partial report\n');
  };
  process.on('SIGINT', onSignal);
  process.on('SIGTERM', onSignal);

  const t0 = Date.now();
  await Promise.all(Array.from({ length: CONCURRENCY }, (_, i) => worker(i, browser)));
  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);

  if (browser) await browser.close();

  const outPath = v.out || path.join(process.cwd(), `loadtest-report-${Date.now()}.html`);
  fs.writeFileSync(outPath, buildReport());

  const summary = buildSummary();
  const jsonPath = v.out ? v.out.replace(/\.html$/i, '') + '.json' : outPath.replace(/\.html$/i, '') + '.json';
  fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2));

  if (v.json) {
    process.stdout.write(JSON.stringify(summary, null, 2) + '\n');
  }

  const errors = samples.filter((s) => s.err).length;
  const nonOk = samples.filter((s) => !s.err && (s.status < 200 || s.status >= 400)).length;
  process.stdout.write(`\n  done in ${elapsed}s  ${samples.length} requests  ${errors} transport errors  ${nonOk} bad status\n`);
  process.stdout.write(`  report: ${outPath}\n`);
}

main().catch((e) => {
  console.error('harness failed:', e);
  process.exit(1);
});