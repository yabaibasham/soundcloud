# language: powershell, file: verify-proxy.ps1, runtime: PowerShell 5.1+, target: Windows 10/11
# Probes the hardened proxy and asserts each control actually fires.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = 'Continue'

$token = $env:LOADLAB_TOKEN
if (-not $token) { $token = 's3cret-run-token' }
$base = 'https://localhost:8443'

function Probe($name, $headers, $expected) {
  try {
    $r = Invoke-WebRequest "$base/health" -UseBasicParsing -Headers $headers -TimeoutSec 10
    $got = $r.StatusCode
    $body = $r.Content
    $hdr = $r.Headers
  } catch {
    $got = $_.Exception.Response.StatusCode.value__
    $body = ''
    $hdr = $null
  }
  $mark = if ($got -eq $expected) { 'PASS' } else { 'FAIL' }
  Write-Host ("{0}  {1,-26} expected {2} got {3}" -f $mark, $name, $expected, $got)
  return @{ code = $got; body = $body; headers = $hdr; pass = ($got -eq $expected) }
}

Write-Host ''
Write-Host '=== auth ==='
$a = Probe 'no credentials' @{} 401
$b = Probe 'wrong token' @{ Authorization = 'Bearer wrong-token' } 401
$c = Probe 'valid token' @{ Authorization = "Bearer $token" } 200
Write-Host ("      body (200): {0}" -f $c.body)

Write-Host ''
Write-Host '=== security headers on an authorized response ==='
if ($c.headers) {
  foreach ($h in @('Strict-Transport-Security', 'Content-Security-Policy', 'X-Content-Type-Options', 'X-Frame-Options', 'Referrer-Policy', 'Cross-Origin-Resource-Policy')) {
    $val = $c.headers[$h]
    $mark = if ($val) { 'PASS' } else { 'FAIL' }
    Write-Host ("{0}  {1,-30} {2}" -f $mark, $h, $val)
  }
}

Write-Host ''
Write-Host '=== error bodies leak nothing ==='
Write-Host ("      401 body: {0}" -f $a.body)
if ($a.body -match 'at |Error|\.js:|node:') { Write-Host 'FAIL  401 body contains internals' } else { Write-Host 'PASS  401 body is terse' }

Write-Host ''
Write-Host '=== TLS negotiation ==='
$tcp = New-Object Net.Sockets.TcpClient('localhost', 8443)
$ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, ({ $true } -as [Net.Security.RemoteCertificateValidationCallback]))
$ssl.AuthenticateAsClient('localhost')
Write-Host ("      negotiated: {0}  cipher: {1}" -f $ssl.SslProtocol, $ssl.CipherAlgorithm)
$ssl.Close(); $tcp.Close()
if ($ssl.SslProtocol -in @('Tls12', 'Tls13')) { Write-Host 'PASS  TLS >= 1.2' } else { Write-Host 'FAIL  TLS below 1.2' }