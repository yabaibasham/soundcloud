# language: powershell, file: trust-cert.ps1, runtime: PowerShell 5.1+, target: Windows 10/11
# Installs cert/server.cert.pem into the CurrentUser trusted ROOT store so this
# machine's browsers, curl, and Node accept the proxy without a warning.
#
# CurrentUser only - no admin prompt, no machine-wide change, reverses cleanly.
# This trusts a self-signed cert as a ROOT CA. That is the correct store for a
# self-signed leaf, but understand the tradeoff: anything this machine trusts
# will accept certs signed by it. Delete it when the server goes away.
param(
  [string]$CertPath = 'cert\server.cert.pem',
  [switch]$Remove
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$store = 'Cert:\CurrentUser\Root'

if ($Remove) {
  $existing = Get-ChildItem $store | Where-Object { $_.Subject -like 'CN=localhost*' }
  foreach ($c in $existing) {
    Remove-Item "Cert:\CurrentUser\Root\$($c.Thumbprint)" -Force
    Write-Host "removed from trusted roots: $($c.Thumbprint)"
  }
  Write-Host 'done - trust removed'
  return
}

if (-not (Test-Path -LiteralPath $CertPath)) { throw "cert not found: $CertPath - run new-cert.ps1 first" }

$crt = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 (Resolve-Path $CertPath)

$already = Get-ChildItem $store | Where-Object { $_.Thumbprint -eq $crt.Thumbprint }
if ($already) {
  Write-Host "already trusted: $($crt.Thumbprint)"
} else {
  Import-Certificate -FilePath (Resolve-Path $CertPath) -CertStoreLocation $store | Out-Null
  Write-Host "trusted: $($crt.Thumbprint)  ($($crt.Subject))"
}

Write-Host ''
Write-Host 'verify with:'
Write-Host '  curl.exe -s https://localhost:8443/health -H "Authorization: Bearer <token>"'
Write-Host 'remove with:'
Write-Host '  .\trust-cert.ps1 -Remove'