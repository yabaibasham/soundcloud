/* LoadLab front end. No framework, no build step: fetch + DOM. */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (n) => (n === null || n === undefined || n === '' || Number.isNaN(n) ? '—' : Number(n).toLocaleString());
const ms = (n) => (n === null || n === undefined ? '—' : `${Number(n).toLocaleString()}ms`);

const state = {
  view: 'runs',
  runId: null,
  live: { total: 0, errors: 0, elapsedS: 0 },
  liveTl: new Map(),
  sel: new Set(),
  tracks: [],
};

// ---------- api ----------
async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: opts.body ? { 'content-type': 'application/json' } : undefined,
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = { error: text }; }
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}
function flash(el, msg, ok = true) {
  el.className = `msg ${ok ? 'ok' : 'err'}`;
  el.textContent = msg;
  setTimeout(() => { if (el.textContent === msg) el.style.display = 'none'; }, 5200);
}

// ---------- nav ----------
$$('.nav').forEach((n) => n.addEventListener('click', () => {
  $$('.nav').forEach((x) => x.classList.remove('on'));
  n.classList.add('on');
  $$('.view').forEach((v) => v.classList.remove('on'));
  $(`#v-${n.dataset.v}`).classList.add('on');
  state.view = n.dataset.v;
  if (state.view === 'targets') loadTargets();
  if (state.view === 'history') loadHistory();
  if (state.view === 'schedule') loadSchedules();
  if (state.view === 'tracks') loadTracks();
  if (state.view === 'campaign') loadCampaign();
  if (state.view === 'pitches') loadPitches();
}));

// ---------- SSE ----------
function connect() {
  const es = new EventSource('/api/events');
  es.addEventListener('hello', () => { $('#dot').className = 'dot'; $('#live').textContent = 'live'; });
  es.addEventListener('progress', (e) => {
    const d = JSON.parse(e.data);
    if (d.runId !== state.runId) return;
    state.live = d;
    state.liveTl.set(Math.floor(d.elapsedS), d.total);
    renderLive();
    $('#dot').className = 'dot busy';
  });
  es.addEventListener('run', (e) => {
    const d = JSON.parse(e.data);
    $('#dot').className = 'dot';
    if (d.runId === state.runId && d.status !== 'running') {
      $('#r-go').disabled = false;
      $('#r-cancel').disabled = true;
      $('#r-live').textContent = '';
      loadHistory();
      if (d.status === 'done') loadRun(d.runId);
    }
  });
  es.addEventListener('snapshot', (e) => {
    const d = JSON.parse(e.data);
    if (state.view === 'tracks') $('#tr-msg').className = 'msg ok';
  });
  es.onerror = () => { $('#dot').className = 'dot off'; $('#live').textContent = 'reconnecting…'; };
}

// ---------- run ----------
$('#r-go').addEventListener('click', async () => {
  const btn = $('#r-go');
  btn.disabled = true; btn.innerHTML = '<span class="spin"></span> starting…';
  try {
    const body = {
      url: $('#r-url').value,
      transport: $('#r-transport').value,
      concurrency: Number($('#r-conc').value),
      rps: Number($('#r-rps').value),
      durationS: Number($('#r-dur').value),
      rampupS: Number($('#r-ramp').value),
      headers: $('#r-headers').value,
    };
    const saveName = $('#r-savename').value.trim();
    if (saveName) {
      const t = await api('/api/targets', { method: 'POST', body: JSON.stringify({ ...body, name: saveName }) });
      body.targetId = t.id;
      $('#r-savename').value = '';
    }
    const r = await api('/api/runs', { method: 'POST', body: JSON.stringify(body) });
    state.runId = r.runId;
    state.live = { total: 0, errors: 0, elapsedS: 0 };
    state.liveTl.clear();
    $('#r-cancel').disabled = false;
    $('#r-live').textContent = `run #${r.runId} in progress…`;
    flash($('#r-msg'), `Run #${r.runId} started`, true);
    btn.innerHTML = 'Start run';
  } catch (e) {
    flash($('#r-msg'), e.message, false);
    btn.disabled = false; btn.innerHTML = 'Start run';
  }
});

$('#r-cancel').addEventListener('click', async () => {
  if (!state.runId) return;
  try { await api(`/api/runs/${state.runId}/cancel`, { method: 'POST' }); $('#r-live').textContent = 'cancelling…'; }
  catch (e) { flash($('#r-msg'), e.message, false); }
});

function renderLive() {
  const l = state.live;
  const cards = [
    ['Requests', fmt(l.total), 'g'], ['Errors', fmt(l.errors), l.errors ? 'r' : 'g'],
    ['Elapsed', `${l.elapsedS}<small>s</small>`, ''], ['Req/s', fmt(l.total / (l.elapsedS || 1)), ''],
  ];
  $('#r-cards').innerHTML = cards.map(([k, v, c]) =>
    `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${v}</div></div>`).join('');

  const tl = [...state.liveTl.entries()].map(([sec, total]) => ({ sec, total }));
  sparkline($('#r-spark'), tl, 'req/s', (d) => d.total);
  $('#r-timeline').innerHTML = tl.slice(-40).map((b) =>
    `<div class="rowline"><div class="t">+${b.sec}s</div><div class="bar"><i style="width:${
      (b.total / Math.max(1, ...tl.map((x) => x.total))) * 100}%"></i></div><div class="c">${fmt(b.total)}</div></div>`).join('');
}

async function loadRun(id) {
  const r = await api(`/api/runs/${id}`);
  const L = r.p50 === null ? null : r;
  const cards = [
    ['Requests', fmt(r.total), 'g'], ['Errors', fmt(r.errors), r.errors ? 'r' : 'g'],
    ['Throughput', `${fmt(r.throughput)}<small>/s</small>`, ''],
    ['p50', ms(r.p50), ''], ['p95', ms(r.p95), ''], ['p99', ms(r.p99), ''],
    ['Wall', `${r.wall_s}<small>s</small>`, ''], ['Status', esc(r.status), r.status === 'done' ? 'g' : 'y'],
  ];
  $('#r-cards').innerHTML = cards.map(([k, v, c]) =>
    `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${v}</div></div>`).join('');

  const tl = r.timeline.map((b) => ({ sec: b.sec, total: b.ok + b.err, err: b.err, statuses: b.statuses }));
  sparkline($('#r-spark'), tl, 'req/s', (d) => d.total, (d) => d.err);
  const maxB = Math.max(1, ...tl.map((x) => x.total));
  $('#r-timeline').innerHTML = tl.map((b) => {
    const codes = Object.entries(b.statuses).map(([s, c]) => `${s}&times;${c}`).join(' ');
    const cls = b.err / (b.total || 1) > 0.25 ? 'e' : b.err > 0 ? 'y' : '';
    return `<div class="rowline"><div class="t">+${b.sec}s</div><div class="bar ${cls}"><i style="width:${(b.total / maxB) * 100}%"></i></div><div class="c">${codes} &middot; ${b.avg_ms}ms</div></div>`;
  }).join('');
}

function sparkline(svg, data, label, val, errVal) {
  if (!data.length) { svg.innerHTML = ''; return; }
  const W = 800, H = 130, pad = 6;
  const vals = data.map(val);
  const maxV = Math.max(1, ...vals);
  const bw = (W - pad * 2) / data.length;
  const base = H - 20;
  let bars = '', labels = '';
  data.forEach((d, i) => {
    const v = val(d);
    const h = Math.max(1.5, (v / maxV) * (H - 40));
    const x = pad + i * bw;
    const e = errVal ? errVal(d) : 0;
    const pct = v ? e / v : 0;
    const fill = pct > 0.25 ? 'var(--err)' : pct > 0.05 ? 'var(--warn)' : 'var(--acc)';
    bars += `<rect x="${x.toFixed(2)}" y="${(base - h).toFixed(2)}" width="${Math.max(1, bw - 1.5).toFixed(2)}" height="${h.toFixed(2)}" rx="1.5" fill="${fill}" opacity=".92"/>`;
    if (i % Math.ceil(data.length / 10) === 0) labels += `<text class="ax" x="${x.toFixed(2)}" y="${H - 4}">${d.sec}s</text>`;
  });
  let grid = '';
  for (let i = 1; i <= 3; i++) grid += `<line class="gl" x1="${pad}" y1="${(base / 4) * i}" x2="${W - pad}" y2="${(base / 4) * i}"/>`;
  svg.innerHTML = grid + bars + `<text class="ax" x="${W - pad}" y="12" text-anchor="end">peak ${fmt(maxV)} ${label}</text>` + labels;
}

// ---------- targets ----------
async function loadTargets() {
  const ts = await api('/api/targets');
  $('#t-list').innerHTML = ts.length ? ts.map((t) => `<tr>
    <td>${esc(t.name)}</td><td style="color:var(--fg2)">${esc(t.url)}</td>
    <td class="r">${t.concurrency}</td><td class="r">${t.rps || '∞'}</td><td class="r">${t.duration_s}s</td>
    <td><span class="tag ${t.transport === 'browser' ? 't-warn' : 't-dim'}">${esc(t.transport)}</span></td>
    <td class="r"><button class="btn g s" data-run="${t.id}">Run</button>
        <button class="btn d s" data-del="${t.id}">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="7"><div class="empty">No targets yet</div></td></tr>';

  $$('#t-list [data-run]').forEach((b) => b.addEventListener('click', async () => {
    const t = ts.find((x) => x.id === Number(b.dataset.run));
    $('#r-url').value = t.url; $('#r-transport').value = t.transport;
    $('#r-conc').value = t.concurrency; $('#r-rps').value = t.rps; $('#r-dur').value = t.duration_s;
    $('#r-headers').value = t.headers;
    $$('.nav').forEach((x) => x.classList.remove('on'));
    $('.nav[data-v="runs"]').classList.add('on');
    $$('.view').forEach((v) => v.classList.remove('on'));
    $('#v-runs').classList.add('on');
    state.view = 'runs';
    $('#r-go').click();
  }));
  $$('#t-list [data-del]').forEach((b) => b.addEventListener('click', async () => {
    await api(`/api/targets/${b.dataset.del}`, { method: 'DELETE' });
    loadTargets();
  }));
}

$('#t-add').addEventListener('click', async () => {
  try {
    await api('/api/targets', { method: 'POST', body: JSON.stringify({
      name: $('#t-name').value, url: $('#t-url').value, headers: $('#t-headers').value,
      notes: $('#t-notes').value, transport: $('#t-transport').value,
      concurrency: Number($('#t-conc').value), rps: Number($('#t-rps').value),
      durationS: Number($('#t-dur').value),
    }) });
    ['t-name', 't-url', 't-headers', 't-notes'].forEach((id) => ($( `#${id}`).value = ''));
    flash($('#t-msg'), 'Target saved', true);
    loadTargets();
  } catch (e) { flash($('#t-msg'), e.message, false); }
});

// ---------- history ----------
async function loadHistory() {
  const runs = await api('/api/runs?limit=100');
  $('#h-list').innerHTML = runs.length ? runs.map((r) => `<tr data-row="${r.id}" class="${state.sel.has(r.id) ? 'sel' : ''}">
    <td><input type="checkbox" ${state.sel.has(r.id) ? 'checked' : ''} style="width:auto"></td>
    <td class="r">${r.id}</td>
    <td>${esc(r.target_name)}</td>
    <td><span class="tag ${r.status === 'done' ? 't-ok' : r.status === 'failed' ? 't-err' : 't-warn'}">${esc(r.status)}</span></td>
    <td class="r">${fmt(r.total)}</td><td class="r">${fmt(r.errors)}</td><td class="r">${fmt(r.throughput)}</td>
    <td class="r">${ms(r.p50)}</td><td class="r">${ms(r.p95)}</td><td class="r">${ms(r.p99)}</td>
    <td class="r">${r.wall_s ?? '—'}</td>
    <td style="color:var(--dim)">${esc(r.started_at)}</td>
    <td class="r"><button class="btn d s" data-hdel="${r.id}">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="12"><div class="empty">No runs yet — start one from the Load testing tab</div></td></tr>';

  $$('#h-list tr[data-row]').forEach((tr) => {
    const id = Number(tr.dataset.row);
    tr.addEventListener('click', async (e) => {
      if (e.target.tagName === 'INPUT') {
        if (e.target.checked) state.sel.add(id); else state.sel.delete(id);
        tr.classList.toggle('sel', e.target.checked);
        compare();
        return;
      }
      if (e.target.dataset.hdel) {
        await api(`/api/runs/${e.target.dataset.hdel}`, { method: 'DELETE' });
        loadHistory();
        return;
      }
      const r = await api(`/api/runs/${id}`);
      showDetail(r);
    });
  });
}

async function compare() {
  if (state.sel.size < 2) { $('#h-cmp').innerHTML = '<div class="empty">Select runs above to compare</div>'; return; }
  const runs = await api('/api/runs/compare', { method: 'POST', body: JSON.stringify({ ids: [...state.sel] }) });
  const cols = ['Reqs', 'Errors', 'Req/s', 'p50', 'p95', 'p99', 'Wall'];
  const get = (r, k) => ({ Reqs: r.total, Errors: r.errors, 'Req/s': r.throughput, p50: r.p50, p95: r.p95, p99: r.p99, Wall: r.wall_s }[k]);
  let html = '<table><thead><tr><th>Run</th>' + cols.map((c) => `<th class="r">${c}</th>`).join('') + '</tr></thead><tbody>';
  for (const r of runs) {
    html += `<tr><td>#${r.id} ${esc(r.target_name)} <span class="tag ${r.status === 'done' ? 't-ok' : 't-warn'}">${esc(r.status)}</span></td>`;
    for (const c of cols) {
      const v = get(r, c);
      let best = false;
      if (c === 'Errors' || c === 'p50' || c === 'p95' || c === 'p99' || c === 'Wall') {
        best = runs.every((o) => (get(o, c) ?? Infinity) >= (v ?? Infinity));
      } else {
        best = runs.every((o) => (get(o, c) ?? -Infinity) <= (v ?? -Infinity));
      }
      html += `<td class="r" ${best ? 'style="color:var(--ok);font-weight:650"' : ''}>${c.includes('p') || c === 'Wall' ? (v == null ? '—' : `${v}${c === 'Wall' ? 's' : 'ms'}`) : fmt(v)}</td>`;
    }
    html += '</tr>';
  }
  $('#h-cmp').innerHTML = html + '</tbody></table>';
}

function showDetail(r) {
  const cards = [
    ['Requests', fmt(r.total), 'g'], ['Errors', fmt(r.errors), r.errors ? 'r' : 'g'],
    ['Throughput', `${fmt(r.throughput)}<small>/s</small>`, ''], ['Wall', `${r.wall_s ?? '—'}<small>s</small>`, ''],
    ['p50', ms(r.p50), ''], ['p90', ms(r.p90), ''], ['p95', ms(r.p95), ''], ['p99', ms(r.p99), ''],
    ['Max', ms(r.max_ms), ''], ['Concurrency', r.concurrency, ''], ['RPS cap', r.rps_cap || '∞', ''], ['Transport', esc(r.transport), ''],
  ];
  const statuses = Object.entries(r.statusCounts || {});
  const maxC = Math.max(1, ...statuses.map(([, c]) => c));
  const errs = Object.entries(r.errorCounts || {});
  let html = `<div class="grid auto" style="margin-bottom:16px">${cards.map(([k, v, c]) =>
    `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${v}</div></div>`).join('')}</div>`;

  if (statuses.length) {
    html += '<h3 style="font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin:0 0 8px">Status codes</h3><table><tbody>';
    for (const [s, c] of statuses) {
      const cls = +s >= 200 && +s < 300 ? 't-ok' : +s === 429 ? 't-warn' : 't-err';
      html += `<tr><td style="width:80px"><span class="tag ${cls}">${esc(s)}</span></td><td class="r" style="width:80px">${fmt(c)}</td>
        <td class="r" style="width:70px;color:var(--dim)">${((c / r.total) * 100).toFixed(1)}%</td>
        <td><div class="bar"><i style="width:${(c / maxC) * 100}%"></i></div></td></tr>`;
    }
    html += '</tbody></table>';
  }
  if (errs.length) {
    html += '<h3 style="font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin:20px 0 8px">Errors</h3><table><tbody>';
    for (const [reason, c] of errs) html += `<tr><td style="color:var(--fg2)">${esc(reason)}</td><td class="r">${fmt(c)}</td></tr>`;
    html += '</tbody></table>';
  }
  $('#h-detail').innerHTML = html;
}

// ---------- schedules ----------
async function loadSchedules() {
  const [ss, ts] = await Promise.all([api('/api/schedules'), api('/api/targets')]);
  $('#s-target').innerHTML = ts.map((t) => `<option value="${t.id}">${esc(t.name)}</option>`).join('') || '<option value="">no targets</option>';
  $('#s-list').innerHTML = ss.length ? ss.map((s) => `<tr>
    <td>${esc(s.target_name)}</td><td class="r">${s.every_s}s</td>
    <td><span class="tag ${s.enabled ? 't-ok' : 't-dim'}">${s.enabled ? 'active' : 'paused'}</span></td>
    <td style="color:var(--dim)">${esc(s.next_run_at || '—')}</td>
    <td style="color:var(--dim)">${s.last_run_id ? `#${s.last_run_id} ${esc(s.last_run_at || '')}` : '—'}</td>
    <td class="r"><button class="btn g s" data-tog="${s.id}" data-en="${s.enabled}">${s.enabled ? 'Pause' : 'Resume'}</button>
        <button class="btn d s" data-sdel="${s.id}">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="6"><div class="empty">No schedules — create one to run a target on an interval</div></td></tr>';

  $$('#s-list [data-tog]').forEach((b) => b.addEventListener('click', async () => {
    await api(`/api/schedules/${b.dataset.tog}`, { method: 'PUT', body: JSON.stringify({ enabled: b.dataset.en !== '1' }) });
    loadSchedules();
  }));
  $$('#s-list [data-sdel]').forEach((b) => b.addEventListener('click', async () => {
    await api(`/api/schedules/${b.dataset.sdel}`, { method: 'DELETE' });
    loadSchedules();
  }));
}

$('#s-add').addEventListener('click', async () => {
  try {
    await api('/api/schedules', { method: 'POST', body: JSON.stringify({ targetId: Number($('#s-target').value), everyS: Number($('#s-every').value) }) });
    flash($('#s-msg'), 'Schedule created', true);
    loadSchedules();
  } catch (e) { flash($('#s-msg'), e.message, false); }
});

// ---------- tracks ----------
async function loadTracks() {
  const [tracks, sum] = await Promise.all([api('/api/tracks'), api('/api/summary')]);
  state.tracks = tracks;
  $('#tr-cards').innerHTML = [
    ['Total plays', fmt(sum.total.plays), 'o'], ['Total likes', fmt(sum.total.likes), 'o'],
    ['Total reposts', fmt(sum.total.reposts), 'o'], ['Tracks', tracks.length, ''],
    ['Observations', tracks.reduce((a, t) => a + t.observations.length, 0), ''],
  ].map(([k, v, c]) => `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${v}</div></div>`).join('');

  $('#tr-list').innerHTML = tracks.length ? tracks.map((t) => {
    const m = t.observations;
    const last = t.latest;
    let sp = '';
    if (m.length > 1) {
      const vals = m.map((x) => x.plays).filter((x) => x != null);
      if (vals.length > 1) {
        const mn = Math.min(...vals), mx = Math.max(...vals), rg = mx - mn || 1;
        const pts = vals.map((v, i) => `${(i / (vals.length - 1)) * 100},${30 - ((v - mn) / rg) * 26}`).join(' ');
        sp = `<div class="spark"><svg viewBox="0 0 100 34" preserveAspectRatio="none"><polyline points="${pts}"/><circle cx="100" cy="${30 - ((vals[vals.length - 1] - mn) / rg) * 26}" r="2"/></svg></div>`;
      }
    }
    const d = t.delta;
    const dtxt = d ? `${d.plays >= 0 ? '+' : ''}${fmt(d.plays)}` : '—';
    return `<div class="tr">
      ${t.artwork ? `<img class="art" src="${esc(t.artwork)}" alt="">` : '<div class="art"></div>'}
      <div class="meta">
        <div class="ttl">${esc(t.title || t.sc_id)}</div>
        <div class="sid">${t.sc_track_id ? `sc:${esc(t.sc_track_id)}` : esc(t.sc_id)}</div>
        <div class="nums">
          <div class="num"><div class="k">Plays</div><div class="v">${fmt(last && last.plays)}</div></div>
          <div class="num"><div class="k">Likes</div><div class="v">${fmt(last && last.likes)}</div></div>
          <div class="num"><div class="k">Reposts</div><div class="v">${fmt(last && last.reposts)}</div></div>
          <div class="num"><div class="k">Delta</div><div class="v ${d && d.plays > 0 ? 'up' : 'flat'}">${dtxt}</div></div>
        </div>
        ${sp}
        ${m.length ? '' : '<div class="sid" style="margin:8px 0 0">no observations yet</div>'}
        <div style="margin-top:9px"><button class="btn d s" data-tdel="${t.id}">Remove</button></div>
      </div></div>`;
  }).join('') : '<div class="card"><div class="empty">No tracks tracked</div></div>';

  $('#o-track').innerHTML = tracks.map((t) => `<option value="${t.id}">${esc(t.title || t.sc_id)}</option>`).join('');
  $$('#tr-list [data-tdel]').forEach((b) => b.addEventListener('click', async () => {
    await api(`/api/tracks/${b.dataset.tdel}`, { method: 'DELETE' });
    loadTracks();
  }));
}

$('#tr-add').addEventListener('click', async () => {
  try {
    await api('/api/tracks', { method: 'POST', body: JSON.stringify({ url: $('#tr-url').value }) });
    $('#tr-url').value = '';
    flash($('#tr-msg'), 'Track added — use "Refresh metadata" to pull its title and artwork', true);
    loadTracks();
  } catch (e) { flash($('#tr-msg'), e.message, false); }
});

$('#tr-snap').addEventListener('click', async () => {
  const b = $('#tr-snap');
  b.disabled = true; b.innerHTML = '<span class="spin"></span>';
  try {
    const r = await api('/api/tracks/snapshot', { method: 'POST' });
    flash($('#tr-msg'), `Refreshed ${r.ok} track(s)${r.failed ? `, ${r.failed} failed` : ''}`, r.failed === 0);
    loadTracks();
  } catch (e) { flash($('#tr-msg'), e.message, false); }
  finally { b.disabled = false; b.innerHTML = 'Refresh metadata'; }
});

$('#o-save').addEventListener('click', async () => {
  try {
    await api(`/api/tracks/${$('#o-track').value}/observe`, { method: 'POST', body: JSON.stringify({
      plays: $('#o-plays').value, likes: $('#o-likes').value,
      reposts: $('#o-reposts').value, comments: $('#o-comments').value, note: $('#o-note').value,
    }) });
    ['o-plays', 'o-likes', 'o-reposts', 'o-comments', 'o-note'].forEach((id) => ($( `#${id}`).value = ''));
    flash($('#tr-msg'), 'Observation saved', true);
    loadTracks();
  } catch (e) { flash($('#tr-msg'), e.message, false); }
});

// ---------- campaign ----------
async function loadCampaign() {
  const d = await api('/api/campaign');
  $('#cp-cards').innerHTML = [
    ['Tasks', d.stats.total, ''], ['Posted', d.stats.byStatus.done || 0, 'g'],
    ['Scheduled', d.stats.byStatus.scheduled || 0, 'y'], ['Planned', d.stats.byStatus.planned || 0, ''],
    ['Completion', `${d.stats.completion}%`, d.stats.completion === 100 ? 'g' : ''],
  ].map(([k, v, c]) => `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${v}</div></div>`).join('');

  const byChannel = {};
  for (const c of d.channels) byChannel[c.key] = { label: c.label, n: 0 };
  for (const t of d.tasks) if (byChannel[t.channel]) byChannel[t.channel].n += 1;

  $('#cp-list').innerHTML = d.tasks.slice(0, 12).map((t) => {
    const label = (d.channels.find((c) => c.key === t.channel) || {}).label || t.channel;
    const cls = t.status === 'done' ? 't-ok' : t.status === 'scheduled' ? 't-warn' : t.status === 'skipped' ? 't-dim' : 't-acc';
    return `<tr><td class="r">${t.day}</td><td style="color:var(--dim)">${esc(t.scheduledDate || '')}</td>
      <td>${esc(label)}</td><td>${esc(t.title)}</td>
      <td><span class="tag ${cls}">${esc(t.status)}</span></td></tr>`;
  }).join('');
}

// ---------- playlist pitches ----------
let PITCH = { pitches: [], statuses: [], routes: [], tracks: [] };

async function loadPitches() {
  PITCH = await api('/api/pitches');
  const s = PITCH.stats;
  $('#pi-cards').innerHTML = [
    ['Total pitches', s.total, ''], ['Touched', s.touched, 'y'],
    ['Submitted', s.submitted, 'g'], ['Landed', s.landed, 'g'],
    ['Hit rate', `${s.hitRate}%`, s.hitRate > 0 ? 'g' : ''],
    ['Still to pitch', s.byStatus.to_pitch, ''],
  ].map(([k, v, c]) => `<div class="stat ${c}"><div class="k">${k}</div><div class="n">${fmt(v)}</div></div>`).join('');

  const trackOpts = (sel, withAll) => (withAll ? '<option value="">All tracks</option>' : '') +
    PITCH.tracks.map((t) => `<option value="${esc(t.sc_id)}">${esc(t.title || t.sc_id)}</option>`).join('');
  $('#pi-track').innerHTML = trackOpts('#pi-track', true);
  $('#pi-new-track').innerHTML = trackOpts('#pi-new-track', false);
  $('#pi-status').innerHTML = '<option value="">All statuses</option>' +
    PITCH.statuses.map((x) => `<option value="${x.key}">${esc(x.label)}</option>`).join('');
  $('#pi-new-route').innerHTML = PITCH.routes.map((r) => `<option value="${r.key}">${esc(r.label)}</option>`).join('');

  const ft = $('#pi-track').value, fs = $('#pi-status').value;
  const rows = PITCH.pitches.filter((p) => (!ft || p.track_sc_id === ft) && (!fs || p.status === fs));
  $('#pi-count').textContent = `${rows.length} of ${PITCH.pitches.length}`;

  const shortTitle = (sc) => { const t = PITCH.tracks.find((x) => x.sc_id === sc); return t && t.title ? t.title : sc; };
  const cls = { to_pitch: 't-dim', submitted: 't-warn', in_review: 't-warn', shortlisted: 't-acc', accepted: 't-ok', declined: 't-err', no_response: 't-dim' };

  $('#pi-list').innerHTML = rows.length ? rows.map((p) => `<tr data-id="${p.id}">
    <td style="color:var(--fg2)">${esc(shortTitle(p.track_sc_id))}</td>
    <td>${esc(p.curator)}${p.focus ? `<div class="muted" style="font-size:11px">${esc(p.focus)}</div>` : ''}</td>
    <td><span class="tag t-dim">${esc(p.route)}</span></td>
    <td><select class="stsel" data-pstatus="${p.id}" style="padding:5px 8px;font-size:12px">
      ${PITCH.statuses.map((x) => `<option value="${x.key}" ${x.key === p.status ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}
    </select></td>
    <td class="r"><input type="number" min="0" value="${p.plays_7d ?? ''}" data-pplays="${p.id}" placeholder="—" style="padding:5px 8px;font-size:12px;width:90px"></td>
    <td style="color:var(--dim)">${p.submitted_at ? esc(p.submitted_at.slice(0, 10)) : '—'}</td>
    <td class="r"><button class="btn d s" data-pdel="${p.id}">Delete</button></td></tr>`).join('')
    : '<tr><td colspan="7"><div class="empty">No pitches match this filter</div></td></tr>';

  $$('[data-pstatus]').forEach((s) => s.addEventListener('change', async () => {
    try { await api(`/api/pitches/${s.dataset.pstatus}`, { method: 'PUT', body: JSON.stringify({ status: s.value }) }); loadPitches(); }
    catch (e) { flash($('#pi-msg'), e.message, false); }
  }));
  $$('[data-pplays]').forEach((i) => i.addEventListener('change', async () => {
    try { await api(`/api/pitches/${i.dataset.pplays}`, { method: 'PUT', body: JSON.stringify({ plays7d: i.value }) }); loadPitches(); }
    catch (e) { flash($('#pi-msg'), e.message, false); }
  }));
  $$('[data-pdel]').forEach((b) => b.addEventListener('click', async () => {
    await api(`/api/pitches/${b.dataset.pdel}`, { method: 'DELETE' });
    loadPitches();
  }));
}

$('#pi-add').addEventListener('click', async () => {
  try {
    await api('/api/pitches', { method: 'POST', body: JSON.stringify({
      trackScId: $('#pi-new-track').value, curator: $('#pi-new-curator').value,
      route: $('#pi-new-route').value, focus: $('#pi-new-focus').value, note: $('#pi-new-note').value,
    }) });
    ['pi-new-curator', 'pi-new-focus', 'pi-new-note'].forEach((id) => ($( `#${id}`).value = ''));
    flash($('#pi-msg'), 'Pitch added', true);
    loadPitches();
  } catch (e) { flash($('#pi-msg'), e.message, false); }
});

// ---------- export ----------
$('#e-go').addEventListener('click', async () => {
  const d = await api('/api/export');
  const blob = new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `loadlab-export-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
});

connect();
loadTracks();