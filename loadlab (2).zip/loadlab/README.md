# LoadLab — Growth Suite

Local-first suite for an independent artist releasing five tracks: track analytics,
a 14-day campaign planner, and a load-testing harness. Everything runs on your own
machine. Nothing is hosted, nothing is sent anywhere except the two endpoints you
explicitly target.

## Requirements

- **Node.js 24 or newer.** Uses the built-in `node:sqlite` module, added in Node 22.5.
  Check with `node --version`. On Node 20/22 you will get a module-not-found error.
- No database server, no build step, no npm install required for the core app.
- Playwright is **optional**, needed only for the browser transport in the load tester.

## Run it

Two terminals, or run the mock target only if you want to test against something else.

```powershell
# terminal 1 — the app
cd <this folder>
node server.js
# -> LoadLab  http://127.0.0.1:8080

# terminal 2 — optional local target for load tests
node mock-server.js --host 127.0.0.1 --port 8787 --limit 400 --window 10000
# -> mock-server listening on http://127.0.0.1:8787
```

Then open:

| Page | Address |
|---|---|
| Main app | http://127.0.0.1:8080/ |
| Campaign planner | http://127.0.0.1:8080/campaign-planner.html |
| Campaign CSV | http://127.0.0.1:8080/api/campaign.csv |

To use the browser transport, install it first:

```powershell
npm install
npx playwright install chromium
```

## What each part does

### Track analytics

Five tracks preloaded. **Metadata** (title, author, artwork, numeric track ID) is pulled
from SoundCloud's public oEmbed endpoint — no auth, no API key.

**Play, like and repost counts are entered by you.** This is not a limitation that can be
worked around; see "What this app does not do" below. Read the numbers from your
SoundCloud dashboard and record them. Each observation is timestamped, so the app can
show genuine deltas and per-track sparklines over time.

Record numbers **at a consistent interval** — weekly is fine. Two entries seconds apart
produce a meaningless growth rate, because the rate is real arithmetic on an interval
that isn't real.

### Campaign planner

A 14-day release sprint across all five tracks: 21 seeded tasks covering SoundCloud,
Instagram, TikTok, YouTube, X, Discord, playlist pitching, blog/press, email list, and
live/radio.

- Collapsible per-day sections with progress bars
- Status: planned → scheduled → posted (or skipped), plus editable dates
- Suggested captions with one-click copy
- Channel and status filters
- CSV export (RFC 4180 quoted, so commas in captions don't break columns)
- Edits persist in SQLite between sessions

The seed content is a **starting plan, not a locked schedule.** It's written for
Australian rap/hip-hop release cycles. Rewrite the captions in your own voice — captions
that sound like a press release get ignored.

### LoadLab

A concurrency load tester for **systems you own or are explicitly authorized to test.**

- N async workers with ramp-up and a shared token bucket, so `--rps` is a real ceiling
- Two transports: `http` (fetch, high throughput) and `browser` (headless Chromium,
  measures full render)
- Latency percentiles (p50/p90/p95/p99), status and error rollups, per-second timeline
- Targets saved as reusable profiles; schedules to run them on an interval
- Run history with cross-run comparison and full drill-down
- Live progress streamed over SSE while a run is in progress
- JSON export of everything

Data lives in `data/loadlab.db`.

## What this app does not do

Stated plainly, because a growth suite that pretends otherwise wastes your time:

- **It does not manufacture plays, likes, reposts, follows, or impressions.** There are no
  view bots, no automated listens, no engagement automation anywhere in this codebase.
- **It does not integrate the SoundCloud API.** Play/like/repost counts are not available
  from any public endpoint without a registered API credential and authorized OAuth flow
  under SoundCloud's current developer terms. Until you have that, you enter numbers
  manually. That is why the input form exists.
- **It does not integrate the X/Twitter API.** The campaign planner includes posting
  *plans* and *captions*, not a live publishing integration.
- **It does not post anything to any platform.** Every social action is manual, by you.
- **This is a local application, not a hosted service.** It binds `127.0.0.1` by default.

One practical note on automating listens against real tracks: play counts are computed
server-side from verified events, so synthetic plays move the counter without moving
ranking or recommendation placement. The automation pattern is also the thing platforms
detect and act on. Your actual asset is the music and the account — both of which are
damaged by a suspension, and neither of which you can get back.

## Configuration

```powershell
node server.js --port 8080 --host 127.0.0.1 --db ./data/loadlab.db
```

| Flag | Default | Notes |
|---|---|---|
| `--port` | `8080` | or set `$env:PORT` |
| `--host` | `127.0.0.1` | changing this exposes the app to your network |
| `--db` | `./data/loadlab.db` | SQLite file, safe to back up by copying |

`--host 0.0.0.0` binds every interface and prints a warning. Anyone who can reach the
port can start load runs on your machine and read your analytics. Don't do it on an
untrusted network.

## Security

**Binding.** Loopback only by default. Do not port-forward this. There is no auth layer
on the app itself — it assumes a single user on a trusted machine, which is what a local
dev tool is. If you need remote access, put it behind a reverse proxy that terminates TLS
and handles authentication.

**What is stored.** All data is local in `data/loadlab.db`. Headers you save on a target
may contain bearer tokens, and those are stored **in plaintext** in that file. Treat the
file as a credential store:

- Don't commit it to git
- Don't put it in OneDrive/Dropbox/iCloud without thinking — those sync plaintext to
  third-party servers. If the folder is synced, so are your tokens.
- Delete it when you're done: stop the server, delete `data/loadlab.db`

If a token leaks, rotate it at the source. Deleting the row does not un-leak it.

**Proxy lists.** If you have proxy lists or credentials from anywhere — shared proxy
pools, scraped lists, purchased lists — rotate or revoke them before reuse. Bundled
archives are a common way those leak, and a proxy provider can generally see and log
everything that flows through their infrastructure, including your IP.

**Browser transport.** Headless Chromium is a real browser with a real profile. It loads
whatever URL you give it. Don't point it at anything you'd avoid opening yourself.

**The oEmbed calls** go to `soundcloud.com` and include only the public track URL. No
credentials are sent. Calls are paced at ~700ms apart because it's a free public
endpoint.

## Troubleshooting

**`Cannot find module 'node:sqlite'`** — Node is older than 22.5. Upgrade to Node 24.

**`playwright` browser transport fails** — run `npx playwright install chromium`. The http
transport needs no extra packages.

**Run shows thousands of transport errors** — the target is down or unreachable. Check it
directly first: `curl http://127.0.0.1:8787/health`. A clean run with 429s and
`errors: 0` means the rate limiter is working, not that something broke.

**Everything is 401 from the mock server** — it was started with `--token`. Pass the same
value in the load tester's headers field as `Authorization:Bearer <value>`.

**Port already in use** — `Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 8080`
to find the PID, then stop it. Or just pass a different `--port`.

**Campaign planner shows no tasks** — a restart may have hit a partial seed. Click
**Reset plan** in the planner header.