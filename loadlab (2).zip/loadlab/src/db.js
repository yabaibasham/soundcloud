// language: javascript, file: src/db.js, runtime: Node 24+, target: any
// SQLite persistence for LoadLab. Uses node:sqlite (built into Node 22.5+), so there
// is no native module to compile and no external DB to run.
//
// Design notes:
//  - Every query is a prepared statement; there is no string interpolation of values.
//  - Runs store their latency distribution as percentiles rather than every sample,
//    because a 10-minute run at 5k rps is millions of rows and nobody reads them.
//    Per-second timeline rows and status/error rollups are kept for the charts.
'use strict';

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS targets (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT NOT NULL,
  url          TEXT NOT NULL,
  headers      TEXT NOT NULL DEFAULT '',
  notes        TEXT NOT NULL DEFAULT '',
  concurrency  INTEGER NOT NULL DEFAULT 40,
  rps          INTEGER NOT NULL DEFAULT 0,
  duration_s   INTEGER NOT NULL DEFAULT 15,
  transport    TEXT NOT NULL DEFAULT 'http',
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS runs (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  target_id      INTEGER REFERENCES targets(id) ON DELETE SET NULL,
  target_name    TEXT NOT NULL DEFAULT '',
  url            TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'running',
  started_at     TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at    TEXT,
  wall_s         REAL,
  concurrency    INTEGER NOT NULL,
  rps_cap        INTEGER NOT NULL DEFAULT 0,
  rampup_s       INTEGER NOT NULL DEFAULT 0,
  transport      TEXT NOT NULL,
  total          INTEGER NOT NULL DEFAULT 0,
  errors         INTEGER NOT NULL DEFAULT 0,
  throughput     REAL NOT NULL DEFAULT 0,
  mean_ms        REAL, p50 REAL, p90 REAL, p95 REAL, p99 REAL, max_ms REAL,
  error_message  TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_started ON runs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_target  ON runs(target_id, started_at DESC);

CREATE TABLE IF NOT EXISTS run_statuses (
  run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  status INTEGER NOT NULL,
  count  INTEGER NOT NULL,
  PRIMARY KEY (run_id, status)
);

CREATE TABLE IF NOT EXISTS run_timeline (
  run_id      INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  sec         INTEGER NOT NULL,
  ok          INTEGER NOT NULL DEFAULT 0,
  err         INTEGER NOT NULL DEFAULT 0,
  avg_ms      REAL NOT NULL DEFAULT 0,
  statuses    TEXT NOT NULL DEFAULT '{}',
  PRIMARY KEY (run_id, sec)
);

CREATE TABLE IF NOT EXISTS run_errors (
  run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  count  INTEGER NOT NULL,
  PRIMARY KEY (run_id, reason)
);

CREATE TABLE IF NOT EXISTS sc_tracks (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  url          TEXT NOT NULL UNIQUE,
  sc_id        TEXT NOT NULL,
  title        TEXT,
  author       TEXT,
  artwork      TEXT,
  sc_track_id  TEXT,
  added_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sc_observations (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id    INTEGER NOT NULL REFERENCES sc_tracks(id) ON DELETE CASCADE,
  observed_at TEXT NOT NULL DEFAULT (datetime('now')),
  plays       INTEGER,
  likes       INTEGER,
  reposts     INTEGER,
  comments    INTEGER,
  note        TEXT
);
CREATE INDEX IF NOT EXISTS idx_obs_track ON sc_observations(track_id, observed_at);

CREATE TABLE IF NOT EXISTS sc_snapshots (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id    INTEGER NOT NULL REFERENCES sc_tracks(id) ON DELETE CASCADE,
  taken_at    TEXT NOT NULL DEFAULT (datetime('now')),
  title       TEXT, author TEXT, artwork TEXT, sc_track_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_snap_track ON sc_snapshots(track_id, taken_at DESC);

CREATE TABLE IF NOT EXISTS schedule (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  target_id    INTEGER NOT NULL REFERENCES targets(id) ON DELETE CASCADE,
  every_s      INTEGER NOT NULL,
  enabled      INTEGER NOT NULL DEFAULT 1,
  next_run_at  TEXT,
  last_run_id  INTEGER,
  last_run_at  TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Applied from campaigns.js; kept here so the schema stays in one place at startup.
CREATE TABLE IF NOT EXISTS campaign_tasks (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  day            INTEGER NOT NULL DEFAULT 1,
  channel        TEXT NOT NULL DEFAULT 'soundcloud',
  track_id       INTEGER REFERENCES sc_tracks(id) ON DELETE SET NULL,
  track_label    TEXT NOT NULL DEFAULT 'all tracks',
  title          TEXT NOT NULL,
  caption        TEXT NOT NULL DEFAULT '',
  notes          TEXT,
  scheduled_date TEXT,
  status         TEXT NOT NULL DEFAULT 'planned',
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaign_day ON campaign_tasks(day, status);

-- Playlist pitching. Applied from pitches.js; kept here so the schema is created in one place.
CREATE TABLE IF NOT EXISTS pitches (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id      INTEGER REFERENCES sc_tracks(id) ON DELETE CASCADE,
  track_sc_id   TEXT NOT NULL,
  curator       TEXT NOT NULL,
  route         TEXT NOT NULL DEFAULT 'direct',
  focus         TEXT NOT NULL DEFAULT '',
  status        TEXT NOT NULL DEFAULT 'to_pitch',
  submitted_at  TEXT,
  responded_at  TEXT,
  plays_7d      INTEGER,
  note          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pitch_status ON pitches(status);
CREATE INDEX IF NOT EXISTS idx_pitch_track  ON pitches(track_sc_id);
`;

class Db {
  constructor(file) {
    this.file = file;
    if (file !== ':memory:') {
      fs.mkdirSync(path.dirname(file), { recursive: true });
    }
    this.raw = new DatabaseSync(file);
    this.raw.exec(SCHEMA);
    this.cacheStatements = new Map();
  }

  // Prepared-statement cache: run configs are read on every request in list paths.
  prep(sql) {
    let s = this.cacheStatements.get(sql);
    if (!s) {
      s = this.raw.prepare(sql);
      this.cacheStatements.set(sql, s);
    }
    return s;
  }

  all(sql, ...args) {
    return this.prep(sql).all(...args).map(plain);
  }

  get(sql, ...args) {
    const r = this.prep(sql).get(...args);
    return r === undefined ? undefined : plain(r);
  }

  run(sql, ...args) {
    return this.prep(sql).run(...args);
  }

  exec(sql) {
    return this.raw.exec(sql);
  }

  transaction(fn) {
    this.raw.exec('BEGIN');
    try {
      const out = fn();
      this.raw.exec('COMMIT');
      return out;
    } catch (e) {
      this.raw.exec('ROLLBACK');
      throw e;
    }
  }

  close() {
    try {
      this.raw.close();
    } catch {
      /* already closed */
    }
  }
}

// node:sqlite returns null-prototype rows, which break JSON.stringify's fast path
// and surprise spread operations. Normalize to plain objects at the boundary.
function plain(row) {
  return Object.assign({}, row);
}

module.exports = { Db, plain };