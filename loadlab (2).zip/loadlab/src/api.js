// language: javascript, file: src/api.js, runtime: Node 24+, target: localhost
// HTTP API + static file serving. Bind loopback by default: this spawns load engines
// and stores your analytics, so it should not be reachable from the network unless you
// deliberately change that.
//
// SSE at GET /api/events streams run progress and schedule ticks.
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { URL } = require('node:url');

const { Engine, parseHeaders } = require('./engine');
const { SoundCloud } = require('./soundcloud');
const { Campaigns } = require('./campaigns');
const { Pitches } = require('./pitches');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');

class Api {
  constructor(db, { logger = console } = {}) {
    this.db = db;
    this.sc = new SoundCloud(db);
    this.campaigns = new Campaigns(db);
    this.pitches = new Pitches(db);
    this.log = logger;
    this.engines = new Map(); // runId -> Engine
    this.clients = new Set(); // SSE responses
    this.sc.seedIfEmpty();
    this.campaigns.seedIfEmpty();
    this.pitches.seedIfEmpty();
  }

  broadcast(event, data) {
    const frame = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of this.clients) {
      try {
        res.write(frame);
      } catch {
        this.clients.delete(res);
      }
    }
  }

  // ---- targets ----------------------------------------------------------
  listTargets() {
    return this.db.all('SELECT * FROM targets ORDER BY id');
  }

  createTarget(b) {
    const name = String(b.name || '').trim();
    const url = String(b.url || '').trim();
    if (!name) throw new Error('name is required');
    if (!/^https?:\/\//i.test(url)) throw new Error('url must start with http:// or https://');
    parseHeaders(b.headers || ''); // validate now rather than at run time
    const r = this.db.run(
      `INSERT INTO targets (name, url, headers, notes, concurrency, rps, duration_s, transport)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      name, url, String(b.headers || ''), String(b.notes || ''),
      clampInt(b.concurrency, 1, 1000, 40), clampInt(b.rps, 0, 200000, 0),
      clampInt(b.durationS, 1, 3600, 15), b.transport === 'browser' ? 'browser' : 'http'
    );
    return this.db.get('SELECT * FROM targets WHERE id = ?', r.lastInsertRowid);
  }

  updateTarget(id, b) {
    const t = this.db.get('SELECT * FROM targets WHERE id = ?', id);
    if (!t) throw new Error('unknown target');
    const url = b.url === undefined ? t.url : String(b.url).trim();
    if (!/^https?:\/\//i.test(url)) throw new Error('url must start with http:// or https://');
    const headers = b.headers === undefined ? t.headers : String(b.headers);
    parseHeaders(headers);
    this.db.run(
      `UPDATE targets SET name = ?, url = ?, headers = ?, notes = ?, concurrency = ?, rps = ?, duration_s = ?, transport = ?
       WHERE id = ?`,
      b.name === undefined ? t.name : String(b.name), url, headers,
      b.notes === undefined ? t.notes : String(b.notes),
      clampInt(b.concurrency, 1, 1000, t.concurrency),
      clampInt(b.rps, 0, 200000, t.rps),
      clampInt(b.durationS, 1, 3600, t.duration_s),
      b.transport === 'browser' ? 'browser' : t.transport,
      id
    );
    return this.db.get('SELECT * FROM targets WHERE id = ?', id);
  }

  deleteTarget(id) {
    this.db.run('DELETE FROM targets WHERE id = ?', id);
  }

  // ---- runs -------------------------------------------------------------
  startRun(body) {
    const targetId = body.targetId ? Number(body.targetId) : null;
    const target = targetId ? this.db.get('SELECT * FROM targets WHERE id = ?', targetId) : null;
    if (targetId && !target) throw new Error('unknown target');

    const cfg = {
      url: String(body.url || (target && target.url) || '').trim(),
      headers: body.headers !== undefined ? body.headers : target ? target.headers : '',
      concurrency: body.concurrency ?? (target && target.concurrency),
      rps: body.rps ?? (target && target.rps),
      durationS: body.durationS ?? (target && target.duration_s),
      rampupS: body.rampupS,
      transport: body.transport ?? (target && target.transport),
    };
    if (!/^https?:\/\//i.test(cfg.url)) throw new Error('url must start with http:// or https://');

    const ins = this.db.run(
      `INSERT INTO runs (target_id, target_name, url, concurrency, rps_cap, rampup_s, transport)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      targetId, target ? target.name : 'ad-hoc', cfg.url,
      clampInt(cfg.concurrency, 1, 1000, 40), clampInt(cfg.rps, 0, 200000, 0),
      clampInt(cfg.rampupS, 0, 600, 2), cfg.transport === 'browser' ? 'browser' : 'http'
    );
    const runId = Number(ins.lastInsertRowid);

    const engine = new Engine(cfg);
    this.engines.set(runId, engine);

    engine.on('progress', (p) => this.broadcast('progress', { runId, ...p }));
    engine.on('done', (s) => {
      this.persistRun(runId, s, null);
      this.engines.delete(runId);
      this.broadcast('run', { runId, status: s.status });
      this.tickSchedules();
    });
    engine.on('failed', (msg) => {
      this.persistRun(runId, { ...engine.summary(), status: 'failed' }, msg);
      this.engines.delete(runId);
      this.broadcast('run', { runId, status: 'failed' });
    });

    engine.run().catch((e) => this.log.error('engine crashed', e));
    this.broadcast('run', { runId, status: 'running' });
    return { runId };
  }

  cancelRun(runId) {
    const e = this.engines.get(runId);
    if (!e) return false;
    e.cancel();
    return true;
  }

  persistRun(runId, s, errorMessage) {
    this.db.transaction(() => {
      this.db.run(
        `UPDATE runs SET status = ?, finished_at = datetime('now'), wall_s = ?, total = ?, errors = ?,
         throughput = ?, mean_ms = ?, p50 = ?, p90 = ?, p95 = ?, p99 = ?, max_ms = ?, error_message = ?
         WHERE id = ?`,
        s.status, s.wallS, s.total, s.errors, s.throughput,
        s.latency.mean, s.latency.p50, s.latency.p90, s.latency.p95, s.latency.p99, s.latency.max,
        errorMessage, runId
      );
      this.db.run('DELETE FROM run_statuses WHERE run_id = ?', runId);
      this.db.run('DELETE FROM run_timeline WHERE run_id = ?', runId);
      this.db.run('DELETE FROM run_errors WHERE run_id = ?', runId);
      for (const [status, count] of Object.entries(s.statusCounts)) {
        this.db.run('INSERT INTO run_statuses (run_id, status, count) VALUES (?, ?, ?)', runId, Number(status), count);
      }
      for (const [reason, count] of Object.entries(s.errorCounts)) {
        this.db.run('INSERT INTO run_errors (run_id, reason, count) VALUES (?, ?, ?)', runId, reason.slice(0, 300), count);
      }
      for (const b of s.timeline) {
        this.db.run(
          'INSERT INTO run_timeline (run_id, sec, ok, err, avg_ms, statuses) VALUES (?, ?, ?, ?, ?, ?)',
          runId, b.sec, b.ok, b.err, b.avgMs, JSON.stringify(b.statuses)
        );
      }
    });
  }

  listRuns(limit = 50) {
    return this.db.all(
      `SELECT id, target_id, target_name, url, status, started_at, finished_at, wall_s,
              concurrency, rps_cap, transport, total, errors, throughput, p50, p95, p99, max_ms, error_message
       FROM runs ORDER BY id DESC LIMIT ?`,
      clampInt(limit, 1, 500, 50)
    );
  }

  getRun(id) {
    const run = this.db.get('SELECT * FROM runs WHERE id = ?', id);
    if (!run) return null;
    run.statusCounts = Object.fromEntries(
      this.db.all('SELECT status, count FROM run_statuses WHERE run_id = ?', id).map((r) => [r.status, r.count])
    );
    run.errorCounts = Object.fromEntries(
      this.db.all('SELECT reason, count FROM run_errors WHERE run_id = ? ORDER BY count DESC', id).map((r) => [r.reason, r.count])
    );
    run.timeline = this.db
      .all('SELECT sec, ok, err, avg_ms, statuses FROM run_timeline WHERE run_id = ? ORDER BY sec', id)
      .map((r) => ({ ...r, statuses: JSON.parse(r.statuses) }));
    return run;
  }

  deleteRun(id) {
    this.db.run('DELETE FROM runs WHERE id = ?', id);
  }

  compareRuns(ids) {
    const runs = ids.map((id) => this.getRun(id)).filter(Boolean);
    return runs;
  }

  // ---- schedules --------------------------------------------------------
  listSchedules() {
    return this.db.all(
      `SELECT s.*, t.name AS target_name, t.url FROM schedule s
       JOIN targets t ON t.id = s.target_id ORDER BY s.id`
    );
  }

  createSchedule(body) {
    const targetId = Number(body.targetId);
    if (!this.db.get('SELECT id FROM targets WHERE id = ?', targetId)) throw new Error('unknown target');
    const everyS = clampInt(body.everyS, 30, 86400, 300);
    const r = this.db.run(
      `INSERT INTO schedule (target_id, every_s, enabled, next_run_at)
       VALUES (?, ?, 1, datetime('now', ?))`,
      targetId, everyS, `+${everyS} seconds`
    );
    this.tickSchedules();
    return this.db.get('SELECT * FROM schedule WHERE id = ?', r.lastInsertRowid);
  }

  updateSchedule(id, b) {
    const s = this.db.get('SELECT * FROM schedule WHERE id = ?', id);
    if (!s) throw new Error('unknown schedule');
    this.db.run(
      'UPDATE schedule SET enabled = ?, every_s = ? WHERE id = ?',
      b.enabled === undefined ? s.enabled : b.enabled ? 1 : 0,
      b.everyS === undefined ? s.every_s : clampInt(b.everyS, 30, 86400, s.every_s),
      id
    );
    this.tickSchedules();
    return this.db.get('SELECT * FROM schedule WHERE id = ?', id);
  }

  deleteSchedule(id) {
    this.db.run('DELETE FROM schedule WHERE id = ?', id);
  }

  tickSchedules() {
    const due = this.db.all(
      "SELECT * FROM schedule WHERE enabled = 1 AND (next_run_at IS NULL OR next_run_at <= datetime('now'))"
    );
    for (const s of due) {
      let runId = null;
      try {
        runId = this.startRun({ targetId: s.target_id }).runId;
      } catch (e) {
        this.log.error(`schedule ${s.id} failed to start`, e.message);
      }
      this.db.run(
        `UPDATE schedule SET last_run_id = ?, last_run_at = datetime('now'), next_run_at = datetime('now', ?) WHERE id = ?`,
        runId, `+${s.every_s} seconds`, s.id
      );
      this.broadcast('schedule', { id: s.id, ran: runId });
    }
  }

  // ---- analytics --------------------------------------------------------
  listTracks() {
    return this.sc.listTracks();
  }

  addTrack(url) {
    return this.sc.addTrack(url);
  }

  deleteTrack(id) {
    this.sc.removeTrack(id);
  }

  async snapshotTracks(onProgress) {
    return this.sc.snapshotAll({ onProgress });
  }

  recordObservation(trackId, data) {
    return this.sc.recordObservation(Number(trackId), data);
  }

  totals() {
    return this.sc.totals();
  }

  // ---- campaigns -------------------------------------------------------
  listCampaigns() {
    return { ...this.campaigns.list(), stats: this.campaigns.stats() };
  }

  addCampaignTask(b) {
    return this.campaigns.add(b);
  }

  updateCampaignTask(id, b) {
    return this.campaigns.update(Number(id), b);
  }

  deleteCampaignTask(id) {
    this.campaigns.remove(Number(id));
  }

  resetCampaign() {
    return { seeded: this.campaigns.reset() };
  }

  campaignCsv() {
    return this.campaigns.csv();
  }

  // ---- pitches -------------------------------------------------------
  listPitches() {
    return this.pitches.list();
  }

  addPitch(b) {
    return this.pitches.add(b);
  }

  updatePitch(id, b) {
    return this.pitches.update(Number(id), b);
  }

  deletePitch(id) {
    this.pitches.remove(Number(id));
  }

  pitchCsv() {
    return this.pitches.csv();
  }

  // ---- export -----------------------------------------------------------
  exportData() {
    return {
      exportedAt: new Date().toISOString(),
      targets: this.listTargets(),
      runs: this.db.all('SELECT * FROM runs ORDER BY id'),
      tracks: this.listTracks(),
      schedules: this.listSchedules(),
      campaign: this.campaigns.list(),
      pitches: this.pitches.list().pitches,
    };
  }
}

function clampInt(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

// ---- HTTP layer ---------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
};

function createServer(api) {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const p = url.pathname;

    try {
      if (p === '/api/events') return sse(req, res, api);
      if (p.startsWith('/api/')) return await apiRoute(req, res, url, api);
      return serveStatic(res, p);
    } catch (e) {
      // Validation failures and unknown ids are client errors (4xx); anything else is a 500.
      const clientError =
        e.status === 400 ||
        /(unknown |must |is required|is not |need |enter |not a |already |scheduledDate |url |^invalid )/i.test(e.message);
      if (!res.headersSent) json(res, clientError ? 400 : 500, { error: e.message });
      else res.destroy();
    }
  });
}

function sse(req, res, api) {
  res.writeHead(200, {
    'content-type': 'text/event-stream',
    'cache-control': 'no-cache',
    connection: 'keep-alive',
  });
  res.write(`event: hello\ndata: ${JSON.stringify({ at: new Date().toISOString() })}\n\n`);
  api.clients.add(res);
  const ka = setInterval(() => {
    try { res.write(': keepalive\n\n'); } catch { /* dropped */ }
  }, 25000);
  req.on('close', () => {
    clearInterval(ka);
    api.clients.delete(res);
  });
}

async function apiRoute(req, res, url, api) {
  const p = url.pathname;
  const m = req.method;
  const seg = p.split('/').filter(Boolean); // ['api', ...]

  if (seg[1] === 'targets') {
    const id = seg[2] ? Number(seg[2]) : null;
    if (m === 'GET' && !id) return json(res, 200, api.listTargets());
    if (m === 'POST' && !id) return json(res, 201, api.createTarget(await body(req)));
    if (m === 'PUT' && id) return json(res, 200, api.updateTarget(id, await body(req)));
    if (m === 'DELETE' && id) { api.deleteTarget(id); return json(res, 200, { ok: true }); }
  }

  if (seg[1] === 'runs') {
    if (m === 'GET' && !seg[2]) return json(res, 200, api.listRuns(url.searchParams.get('limit')));
    if (m === 'POST' && !seg[2]) return json(res, 201, api.startRun(await body(req)));
    if (m === 'GET' && seg[2]) {
      const r = api.getRun(Number(seg[2]));
      return r ? json(res, 200, r) : json(res, 404, { error: 'unknown run' });
    }
    if (m === 'POST' && seg[2] === 'cancel') return json(res, 200, { cancelled: api.cancelRun(Number(seg[3])) });
    if (m === 'DELETE' && seg[2]) { api.deleteRun(Number(seg[2])); return json(res, 200, { ok: true }); }
    if (m === 'POST' && seg[2] === 'compare') {
      const b = await body(req);
      return json(res, 200, api.compareRuns((b.ids || []).slice(0, 8)));
    }
  }

  if (seg[1] === 'schedules') {
    const id = seg[2] ? Number(seg[2]) : null;
    if (m === 'GET' && !id) return json(res, 200, api.listSchedules());
    if (m === 'POST' && !id) return json(res, 201, api.createSchedule(await body(req)));
    if (m === 'PUT' && id) return json(res, 200, api.updateSchedule(id, await body(req)));
    if (m === 'DELETE' && id) { api.deleteSchedule(id); return json(res, 200, { ok: true }); }
  }

  if (seg[1] === 'tracks') {
    if (m === 'GET') return json(res, 200, api.listTracks());
    if (m === 'POST' && !seg[2]) return json(res, 201, api.addTrack((await body(req)).url));
    if (m === 'DELETE' && seg[2]) { api.deleteTrack(Number(seg[2])); return json(res, 200, { ok: true }); }
    if (m === 'POST' && seg[3] === 'snapshot') {
      const out = await api.snapshotTracks((id) => api.broadcast('snapshot', { scId: id }));
      return json(res, 200, out);
    }
    if (m === 'POST' && seg[3] === 'observe') {
      return json(res, 201, api.recordObservation(seg[2], await body(req)));
    }
  }

  if (seg[1] === 'pitches' && m === 'GET') return json(res, 200, api.listPitches());
  if (seg[1] === 'pitches' && m === 'POST') return json(res, 201, api.addPitch(await body(req)));
  if (seg[1] === 'pitches.csv' && m === 'GET') {
    const b = Buffer.from(api.pitchCsv(), 'utf8');
    res.writeHead(200, {
      'content-type': 'text/csv; charset=utf-8',
      'content-disposition': 'attachment; filename="playlist-pitches.csv"',
      'content-length': b.length,
    });
    return res.end(b);
  }
  if (seg[1] === 'pitches' && m === 'PUT' && seg[2]) return json(res, 200, api.updatePitch(seg[2], await body(req)));
  if (seg[1] === 'pitches' && m === 'DELETE' && seg[2]) { api.deletePitch(seg[2]); return json(res, 200, { ok: true }); }

  if (seg[1] === 'campaign' && m === 'GET') return json(res, 200, api.listCampaigns());
  if (seg[1] === 'campaign' && m === 'POST') {
    const b = await body(req);
    if (b.action === 'reset') return json(res, 200, api.resetCampaign());
    return json(res, 201, api.addCampaignTask(b));
  }
  if (seg[1] === 'campaign' && m === 'PUT' && seg[2]) {
    return json(res, 200, api.updateCampaignTask(seg[2], await body(req)));
  }
  if (seg[1] === 'campaign' && m === 'DELETE' && seg[2]) {
    api.deleteCampaignTask(seg[2]);
    return json(res, 200, { ok: true });
  }
  if (seg[1] === 'campaign.csv' && m === 'GET') {
    const b = Buffer.from(api.campaignCsv(), 'utf8');
    res.writeHead(200, {
      'content-type': 'text/csv; charset=utf-8',
      'content-disposition': 'attachment; filename="campaign-plan.csv"',
      'content-length': b.length,
    });
    return res.end(b);
  }

  if (seg[1] === 'summary' && m === 'GET') return json(res, 200, api.totals());
  if (seg[1] === 'export' && m === 'GET') return json(res, 200, api.exportData());
  if (seg[1] === 'health' && m === 'GET') return json(res, 200, { ok: true, at: new Date().toISOString() });

  return json(res, 404, { error: 'not_found', route: `${m} ${p}` });
}

function json(res, status, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': b.length });
  res.end(b);
}

function body(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => {
      d += c;
      if (d.length > 1e6) reject(new Error('request body too large'));
    });
    req.on('end', () => {
      if (!d) return resolve({});
      try {
        resolve(JSON.parse(d));
      } catch {
        reject(new Error('invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(res, p) {
  const rel = p === '/' ? 'index.html' : p.replace(/^\/+/, '');
  const file = path.join(PUBLIC_DIR, rel);
  // Path traversal guard: resolved path must stay inside PUBLIC_DIR.
  if (!path.resolve(file).startsWith(path.resolve(PUBLIC_DIR))) {
    return json(res, 403, { error: 'forbidden' });
  }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return json(res, 404, { error: 'not_found', route: p });
  }
  const buf = fs.readFileSync(file);
  res.writeHead(200, {
    'content-type': MIME[path.extname(file)] || 'application/octet-stream',
    'content-length': buf.length,
    'cache-control': 'no-store',
  });
  res.end(buf);
}

module.exports = { Api, createServer, clampInt };