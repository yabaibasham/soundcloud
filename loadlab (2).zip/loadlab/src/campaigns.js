// language: javascript, file: src/campaigns.js, runtime: Node 24+, target: any
// 14-day promotional campaign planner. Backed by SQLite so status, dates and edits
// survive restarts, with CSV export for pasting into whatever the artist actually
// uses day to day.
//
// Seed content is written for the five BASHAM tracks and Australian rap/hip-hop
// release cycles: pre-save and follow funnels, short-form video, playlist and
// community pitching. It is a starting plan to edit, not a locked schedule.
'use strict';

const DAY_COUNT = 14;

const CHANNELS = [
  { key: 'soundcloud', label: 'SoundCloud' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'tiktok', label: 'TikTok' },
  { key: 'youtube', label: 'YouTube' },
  { key: 'x', label: 'X' },
  { key: 'discord', label: 'Discord' },
  { key: 'playlist', label: 'Playlist pitch' },
  { key: 'blog', label: 'Blog / press' },
  { key: 'email', label: 'Email list' },
  { key: 'live', label: 'Live / radio' },
];

const STATUSES = [
  { key: 'planned', label: 'Planned' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'done', label: 'Posted' },
  { key: 'skipped', label: 'Skipped' },
];

const TRACKS = [
  { sc_id: 'basham_x/demons-and-daemons', hook: 'the flagship — biggest hook, widest audience' },
  { sc_id: 'basham_x/velvet-damage-basham', hook: 'the hard one — lean into the bar' },
  { sc_id: 'basham_x/rainy-days-basham', hook: 'the emotional one — strongest for mood content' },
  { sc_id: 'basham_x/see-me-on-my-grind-basham', hook: 'the freestyle — clip-friendly, no polish needed' },
  { sc_id: 'basham_x/wild-fire-basham', hook: 'the banger — biggest single-shot clip potential' },
];

// day, channel, track index (or null for all-tracks), title, caption, notes
const SEED = [
  [1, 'soundcloud', 3, 'Republish freestyle with a clean title', 'New freestyle up. "LETS GO CITY GRIND" — no filter, no cuts. Headphones on.', 'Make sure the waveform art and title are correct before pushing.'],
  [1, 'instagram', 3, 'Story announcement', 'New one just dropped 🎤 link in bio', 'Story only. Reply to every DM with the link.'],
  [2, 'soundcloud', 2, 'Rainy Days goes live', '"RAINY DAYS" is out. The one you play when it is grey outside and you still have to go in.', 'Mood piece. Pin a comment with the vocal stem if you want comments.'],
  [2, 'tiktok', 2, '15s hook clip', 'the hook. that is the whole post.', 'Use the cleanest 15 seconds. Caption should be near-silent.'],
  [3, 'playlist', 1, 'Pitch Velvet Damage to curators', 'Hard bars, no hook chorus, filthy drums. For editors who like a challenge.', 'Use SubmitHub or direct email to independent rap playlists. Aim 15, accept 3-5.'],
  [3, 'x', 1, 'Quote post', '"VELVET DAMAGE" — the one nobody warned you about.', 'Tag two producers or DJs you respect.'],
  [4, 'soundcloud', 4, 'Wild Fire single drop', '"WILD FIRE" out now. Turn it up or turn it off, no middle.', 'Best day for a single. Post everywhere same hour.'],
  [4, 'tiktok', 4, 'Beat-switch clip', 'switch the beat at the hook. watch to the end.', 'The transition is the whole video. Pin a comment with the track link.'],
  [4, 'instagram', 4, 'Reel — 30s of the banger', 'WILD FIRE 🔥 full track on SoundCloud, link in bio', 'Reel with audio from SoundCloud so it counts as a play.'],
  [5, 'discord', 0, 'Community push', 'New week, new music. Five tracks out — tell me which one actually hits.', 'Ask which track, reply to every answer.'],
  [5, 'soundcloud', 0, 'Repost the catalogue', 'All five are up. Start anywhere.', 'Feature the strongest one in the description.'],
  [6, 'email', 4, 'List email — Wild Fire', 'Subject: WILD FIRE is live\n\nNew single. Full track below. Reply and tell me which line you want on the next one.', 'Only if you have a real opted-in list. Never buy lists.'],
  [7, 'blog', 0, 'Local press angle', 'BASHAM drops five-track run — from the ground, no label', 'Local hip-hop press, student radio, campus papers.'],
  [7, 'x', 2, 'Behind the writing', 'wrote rainy days on a bus at 5am. it was about the walk to work after.', 'Process content performs better than pure promo.'],
  [8, 'youtube', 3, 'Freestyle session video', 'Full freestyle, one take, no cuts.', 'YouTube gives the longest tail. Title for search: "BASHAM freestyle".'],
  [9, 'soundcloud', 0, 'Midpoint check + repost best', 'Two weeks in. Here is what stuck.', 'Look at your own stats — repost whichever track actually moved.'],
  [10, 'instagram', 1, 'Bars-on-screen carousel', 'screenshots of the hardest bars. no caption needed.', 'Carousel of 5 lines. Last slide: link in bio.'],
  [11, 'playlist', 0, 'Second pitch round', 'Five tracks, one lane. Taking submissions.', 'Different curators than day 3. Track which ones respond.'],
  [12, 'discord', 2, 'Listener request', 'Rainy Days — what do you want on part two?', 'Build a list of people who actually reply.'],
  [13, 'live', 0, 'Radio / podcast plug', 'Five tracks, independent, available now.', 'Student and community radio take unplayed artists.'],
  [14, 'soundcloud', 0, 'End of sprint — thank and reset', 'Two weeks. Thanks for listening. Next one is already done.', 'Review which channel produced the most follows, drop the rest.'],
];

class Campaigns {
  constructor(db) {
    this.db = db;
  }

  seedIfEmpty() {
    const n = this.db.get('SELECT COUNT(*) AS n FROM campaign_tasks').n;
    if (n > 0) return 0;

    const tracks = this.db.all('SELECT id, sc_id, title FROM sc_tracks');
    const bySc = new Map(tracks.map((t) => [t.sc_id, t]));
    const start = new Date();
    let created = 0;

    this.db.transaction(() => {
      for (const [day, channel, ti, title, caption, notes] of SEED) {
        const track = ti === null ? null : bySc.get(TRACKS[ti].sc_id);
        const d = new Date(start);
        d.setDate(d.getDate() + (day - 1));
        this.db.run(
          `INSERT INTO campaign_tasks (day, channel, track_id, track_label, title, caption, notes, scheduled_date)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          day, channel, track ? track.id : null, track ? TRACKS[ti].hook : 'all tracks',
          title, caption, notes || null, d.toISOString().slice(0, 10)
        );
        created += 1;
      }
    });
    return created;
  }

  list() {
    const rows = this.db.all(`
      SELECT c.*, t.title AS track_title, t.artwork AS track_artwork
      FROM campaign_tasks c LEFT JOIN sc_tracks t ON t.id = c.track_id
      ORDER BY c.day, c.id
    `);
    return {
      days: DAY_COUNT,
      channels: CHANNELS,
      statuses: STATUSES,
      tasks: rows.map((r) => ({
        id: r.id, day: r.day, channel: r.channel, trackId: r.track_id,
        trackLabel: r.track_label, trackTitle: r.track_title, artwork: r.track_artwork,
        title: r.title, caption: r.caption, notes: r.notes,
        scheduledDate: r.scheduled_date, status: r.status,
      })),
    };
  }

  update(id, body) {
    const t = this.db.get('SELECT * FROM campaign_tasks WHERE id = ?', id);
    if (!t) throw new Error('unknown task');
    const status = body.status === undefined ? t.status : String(body.status);
    if (!STATUSES.some((s) => s.key === status)) {
      throw Object.assign(new Error(`status must be one of ${STATUSES.map((s) => s.key).join(', ')}`), { status: 400 });
    }
    if (body.scheduledDate && !/^\d{4}-\d{2}-\d{2}$/.test(body.scheduledDate)) {
      throw Object.assign(new Error('scheduledDate must be YYYY-MM-DD'), { status: 400 });
    }
    this.db.run(
      'UPDATE campaign_tasks SET status = ?, scheduled_date = ?, title = ?, caption = ?, notes = ? WHERE id = ?',
      status,
      body.scheduledDate === undefined ? t.scheduled_date : body.scheduledDate,
      body.title === undefined ? t.title : String(body.title),
      body.caption === undefined ? t.caption : String(body.caption),
      body.notes === undefined ? t.notes : (body.notes ? String(body.notes) : null),
      id
    );
    return this.db.get('SELECT * FROM campaign_tasks WHERE id = ?', id);
  }

  add(body) {
    const day = Math.min(DAY_COUNT, Math.max(1, Number(body.day) || 1));
    const title = String(body.title || '').trim();
    if (!title) throw new Error('title is required');
    const channel = CHANNELS.some((c) => c.key === body.channel) ? body.channel : 'soundcloud';
    this.db.run(
      `INSERT INTO campaign_tasks (day, channel, track_id, track_label, title, caption, notes, scheduled_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      day, channel, body.trackId ? Number(body.trackId) : null, body.trackLabel || 'custom',
      title, body.caption || '', body.notes || null,
      body.scheduledDate || new Date().toISOString().slice(0, 10)
    );
    const r = this.db.get('SELECT id FROM campaign_tasks ORDER BY id DESC LIMIT 1');
    return this.db.get('SELECT * FROM campaign_tasks WHERE id = ?', r.id);
  }

  remove(id) {
    this.db.run('DELETE FROM campaign_tasks WHERE id = ?', id);
  }

  reset() {
    this.db.run('DELETE FROM campaign_tasks');
    return this.seedIfEmpty();
  }

  stats() {
    const rows = this.db.all('SELECT status, COUNT(*) AS n FROM campaign_tasks GROUP BY status');
    const byStatus = Object.fromEntries(STATUSES.map((s) => [s.key, 0]));
    for (const r of rows) byStatus[r.status] = r.n;
    const total = rows.reduce((a, r) => a + r.n, 0);
    const posted = byStatus.done || 0;
    return { total, byStatus, completion: total ? Number(((posted / total) * 100).toFixed(1)) : 0 };
  }

  // RFC 4180 quoting: fields with commas, quotes or newlines must be quoted, and
  // embedded quotes doubled. Without this, a caption containing a comma breaks the column.
  csv() {
    const rows = this.db.all(`
      SELECT c.day, c.scheduled_date, c.channel, c.status, c.track_label, c.title, c.caption, c.notes
      FROM campaign_tasks c ORDER BY c.day, c.id
    `);
    const header = ['day', 'date', 'channel', 'status', 'track', 'title', 'caption', 'notes'];
    const esc2 = (v) => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [header.join(',')];
    for (const r of rows) {
      lines.push([r.day, r.scheduled_date, r.channel, r.status, r.track_label, r.title, r.caption, r.notes].map(esc2).join(','));
    }
    return lines.join('\r\n');
  }
}

const CAMPAIGN_SCHEMA = `
CREATE TABLE IF NOT EXISTS campaign_tasks (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  day            INTEGER NOT NULL DEFAULT 1,
  channel        TEXT NOT NULL DEFAULT 'soundcloud',
  track_id       INTEGER REFERENCES sc_tracks(id) ON DELETE SET NULL,
  track_label    TEXT NOT NULL DEFAULT 'all tracks',
  title          TEXT NOT NULL,
  caption        TEXT NOT NULL DEFAULT '',
  notes          TEXT,
  scheduled_date TEXT,
  status         TEXT NOT NULL DEFAULT 'planned',
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaign_day ON campaign_tasks(day, status);
`;

module.exports = { Campaigns, CAMPAIGN_SCHEMA, DAY_COUNT, CHANNELS, STATUSES };