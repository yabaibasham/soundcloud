// language: javascript, file: src/engine.js, runtime: Node 24+, target: any host you control
// The load engine. One instance per run, created by the API and driven by the server.
//
// Concurrency model: N async workers in a single event loop, gated by a shared token
// bucket. That gives per-request overhead of a few microseconds rather than a process
// or thread each, so a single instance comfortably sustains several thousand rps.
// Past that the bottleneck is the server under test, not this loop.
//
// Emits: progress (every ~500ms), done, failed.
'use strict';

const { EventEmitter } = require('node:events');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class RateLimiter {
  constructor(rps) {
    this.rps = rps;
    this.tokens = 0;
    this.last = Date.now();
  }

  async take() {
    if (!this.rps) return;
    for (;;) {
      const now = Date.now();
      this.tokens = Math.min(this.rps, this.tokens + ((now - this.last) / 1000) * this.rps);
      this.last = now;
      if (this.tokens >= 1) {
        this.tokens -= 1;
        return;
      }
      await sleep(Math.max(1, Math.ceil(((1 - this.tokens) / this.rps) * 1000)));
    }
  }
}

function parseHeaders(raw) {
  if (!raw) return {};
  const t = String(raw).trim();
  if (t.startsWith('{')) {
    try {
      return JSON.parse(t);
    } catch {
      throw new Error('headers is not valid JSON; use "Key: Value" pairs separated by ;');
    }
  }
  const out = {};
  for (const pair of t.split(';')) {
    const i = pair.indexOf(':');
    if (i > 0) out[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
  }
  return out;
}

class Engine extends EventEmitter {
  constructor(cfg) {
    super();
    this.cfg = {
      url: cfg.url,
      concurrency: clampInt(cfg.concurrency, 1, 1000, 40),
      rps: clampInt(cfg.rps, 0, 200000, 0),
      durationS: clampInt(cfg.durationS, 1, 3600, 15),
      rampupS: clampInt(cfg.rampupS, 0, 600, 2),
      timeoutMs: clampInt(cfg.timeoutMs, 100, 120000, 15000),
      transport: cfg.transport === 'browser' ? 'browser' : 'http',
      headers: parseHeaders(cfg.headers),
    };

    this.startedAt = Date.now();
    this.status = 'running';
    this.total = 0;
    this.errors = 0;
    this.latencies = [];
    this.statusCounts = new Map();
    this.errorCounts = new Map();
    this.timeline = new Map();
    this.cancelled = false;

    this.limiter = new RateLimiter(this.cfg.rps);
    this._worker = this._worker.bind(this);
    this._httpOnce = this._httpOnce.bind(this);
    this._browserOnce = this._browserOnce.bind(this);
  }

  _bucket() {
    const sec = Math.floor((Date.now() - this.startedAt) / 1000);
    if (!this.timeline.has(sec)) {
      this.timeline.set(sec, { sec, ok: 0, err: 0, latSum: 0, latN: 0, statuses: {} });
    }
    return this.timeline.get(sec);
  }

  _record(status, ms, error) {
    const b = this._bucket();
    this.total += 1;
    if (error) {
      this.errors += 1;
      b.err += 1;
      this.errorCounts.set(error, (this.errorCounts.get(error) || 0) + 1);
    } else {
      b.ok += 1;
      this.statusCounts.set(status, (this.statusCounts.get(status) || 0) + 1);
      b.statuses[status] = (b.statuses[status] || 0) + 1;
      if (status >= 200 && status < 400) this.latencies.push(ms);
    }
    b.latSum += ms;
    b.latN += 1;
  }

  async _httpOnce() {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.cfg.timeoutMs);
    const t0 = process.hrtime.bigint();
    try {
      const res = await fetch(this.cfg.url, {
        method: 'GET',
        headers: this.cfg.headers,
        signal: ctrl.signal,
        cache: 'no-store',
      });
      await res.arrayBuffer();
      this._record(res.status, Number(process.hrtime.bigint() - t0) / 1e6, null);
    } catch (e) {
      const reason = e.name === 'AbortError' ? `timeout after ${this.cfg.timeoutMs}ms` : String(e.message || e.name);
      this._record(0, Number(process.hrtime.bigint() - t0) / 1e6, reason);
    } finally {
      clearTimeout(timer);
    }
  }

  async _browserOnce(page) {
    const t0 = process.hrtime.bigint();
    try {
      const res = await page.goto(this.cfg.url, { waitUntil: 'domcontentloaded', timeout: this.cfg.timeoutMs });
      this._record(res ? res.status() : 0, Number(process.hrtime.bigint() - t0) / 1e6, res ? null : 'no response');
    } catch (e) {
      this._record(0, Number(process.hrtime.bigint() - t0) / 1e6, String(e.message || e).split('\n')[0]);
    }
  }

  async _worker(id, browser) {
    const n = this.cfg.concurrency;
    const stagger = n > 1 ? (this.cfg.rampupS * 1000 * id) / (n - 1) : 0;
    if (stagger > 0) await sleep(stagger);
    if (this.cancelled) return;

    let page = null;
    let ctx = null;
    if (this.cfg.transport === 'browser') {
      ctx = await browser.newContext({ extraHTTPHeaders: this.cfg.headers });
      page = await ctx.newPage();
    }

    const deadline = this.startedAt + this.cfg.durationS * 1000;
    while (Date.now() < deadline && !this.cancelled) {
      await this.limiter.take();
      if (this.cancelled) break;
      if (this.cfg.transport === 'browser') await this._browserOnce(page);
      else await this._httpOnce();
    }

    if (ctx) await ctx.close().catch(() => {});
  }

  async run() {
    let browser = null;
    if (this.cfg.transport === 'browser') {
      try {
        const { chromium } = require('playwright');
        browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
      } catch (e) {
        this.status = 'failed';
        this.emit('failed', `browser transport unavailable: ${e.message}. npm install playwright`);
        return;
      }
    }

    const ticker = setInterval(() => this.emit('progress', this.snapshot()), 500);

    try {
      await Promise.all(Array.from({ length: this.cfg.concurrency }, (_, i) => this._worker(i, browser)));
      this.status = this.cancelled ? 'cancelled' : 'done';
    } catch (e) {
      this.status = 'failed';
      this.emit('failed', String(e.message || e));
    } finally {
      clearInterval(ticker);
      if (browser) await browser.close().catch(() => {});
    }

    this.emit('done', this.summary());
  }

  cancel() {
    this.cancelled = true;
  }

  snapshot() {
    return {
      status: this.status,
      total: this.total,
      errors: this.errors,
      elapsedS: Number(((Date.now() - this.startedAt) / 1000).toFixed(1)),
    };
  }

  summary() {
    const l = this.latencies.slice().sort((a, b) => a - b);
    const wall = (Date.now() - this.startedAt) / 1000;
    return {
      status: this.status,
      url: this.cfg.url,
      transport: this.cfg.transport,
      concurrency: this.cfg.concurrency,
      rpsCap: this.cfg.rps,
      rampupS: this.cfg.rampupS,
      startedAt: new Date(this.startedAt).toISOString(),
      finishedAt: new Date().toISOString(),
      wallS: Number(wall.toFixed(2)),
      total: this.total,
      errors: this.errors,
      throughput: Number((this.total / (wall || 1)).toFixed(2)),
      latency: {
        mean: l.length ? Number((l.reduce((a, b) => a + b, 0) / l.length).toFixed(2)) : 0,
        p50: pct(l, 50), p90: pct(l, 90), p95: pct(l, 95), p99: pct(l, 99),
        max: l.length ? Number(l[l.length - 1].toFixed(2)) : 0,
      },
      statusCounts: Object.fromEntries([...this.statusCounts.entries()].sort((a, b) => a[0] - b[0])),
      errorCounts: Object.fromEntries([...this.errorCounts.entries()].sort((a, b) => b[1] - a[1])),
      timeline: [...this.timeline.values()]
        .sort((a, b) => a.sec - b.sec)
        .map((b) => ({ ...b, avgMs: b.latN ? Number((b.latSum / b.latN).toFixed(2)) : 0 })),
    };
  }
}

function pct(sorted, p) {
  if (!sorted.length) return 0;
  const i = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return Number(sorted[i].toFixed(2));
}

function clampInt(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

module.exports = { Engine, parseHeaders };