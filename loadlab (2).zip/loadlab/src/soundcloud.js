// language: javascript, file: src/soundcloud.js, runtime: Node 24+, target: any
// SoundCloud public metadata via oEmbed, plus manual observation recording.
//
// Why manual entry exists: oEmbed exposes title, author, artwork and the numeric track
// id. It does NOT expose play, like or repost counts, and there is no public endpoint
// for them without a registered API credential. Track pages 429 aggressively for
// unauthenticated clients. So counts are read by the artist from their own dashboard
// and recorded here, which is unlimited, free and carries no risk to the account.
'use strict';

const DEFAULT_TRACKS = [
  'https://soundcloud.com/basham_x/demons-and-daemons',
  'https://soundcloud.com/basham_x/velvet-damage-basham',
  'https://soundcloud.com/basham_x/rainy-days-basham',
  'https://soundcloud.com/basham_x/see-me-on-my-grind-basham',
  'https://soundcloud.com/basham_x/wild-fire-basham',
];

function scIdFromUrl(url) {
  const m = String(url).match(/soundcloud\.com\/([^/?#]+)\/([^/?#]+)/i);
  return m ? `${m[1]}/${m[2]}` : null;
}

async function fetchOembed(url, timeoutMs = 20000) {
  const endpoint = `https://soundcloud.com/oembed?url=${encodeURIComponent(url)}&format=json`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(endpoint, {
      signal: ctrl.signal,
      headers: { 'user-agent': 'LoadLab/1.0 (local personal analytics)' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    const html = j.html || '';
    return {
      title: j.title || null,
      author: j.author_name || null,
      artwork: j.thumbnail_url || null,
      scTrackId: (html.match(/tracks%2F(\d+)/) || html.match(/tracks\/(\d+)/) || [])[1] || null,
    };
  } finally {
    clearTimeout(timer);
  }
}

class SoundCloud {
  constructor(db) {
    this.db = db;
  }

  seedIfEmpty() {
    const count = this.db.get('SELECT COUNT(*) AS n FROM sc_tracks').n;
    if (count > 0) return;
    for (const url of DEFAULT_TRACKS) this.addTrack(url, { quiet: true });
  }

  addTrack(url, { quiet = false } = {}) {
    const scId = scIdFromUrl(url);
    if (!scId) throw new Error('not a soundcloud track URL (expected soundcloud.com/user/track)');
    const existing = this.db.get('SELECT * FROM sc_tracks WHERE url = ?', url);
    if (existing) {
      if (!quiet) throw new Error('already tracked');
      return existing;
    }
    this.db.run('INSERT INTO sc_tracks (url, sc_id) VALUES (?, ?)', url, scId);
    return this.db.get('SELECT * FROM sc_tracks WHERE url = ?', url);
  }

  removeTrack(id) {
    this.db.run('DELETE FROM sc_tracks WHERE id = ?', id);
  }

  listTracks() {
    const tracks = this.db.all('SELECT * FROM sc_tracks ORDER BY id');
    return tracks.map((t) => {
      const obs = this.db.all(
        'SELECT observed_at, plays, likes, reposts, comments, note FROM sc_observations WHERE track_id = ? ORDER BY observed_at',
        t.id
      );
      const last = obs[obs.length - 1] || null;
      const first = obs[0] || null;
      const delta = last && first && obs.length > 1
        ? Object.fromEntries(['plays', 'likes', 'reposts', 'comments'].map((k) => [k, (last[k] ?? 0) - (first[k] ?? 0)]))
        : null;
      return { ...t, observations: obs, latest: last, first, delta };
    });
  }

  async snapshotAll({ onProgress } = {}) {
    const tracks = this.db.all('SELECT * FROM sc_tracks ORDER BY id');
    const out = { ok: 0, failed: 0, results: [] };
    for (const t of tracks) {
      if (onProgress) onProgress(t.sc_id);
      try {
        const meta = await fetchOembed(t.url);
        this.db.run(
          'INSERT INTO sc_snapshots (track_id, taken_at, title, author, artwork, sc_track_id) VALUES (?, datetime(\'now\'), ?, ?, ?, ?)',
          t.id, meta.title, meta.author, meta.artwork, meta.scTrackId
        );
        if (meta.title) {
          this.db.run('UPDATE sc_tracks SET title = COALESCE(title, ?), author = COALESCE(author, ?), artwork = COALESCE(artwork, ?), sc_track_id = COALESCE(sc_track_id, ?) WHERE id = ?',
            meta.title, meta.author, meta.artwork, meta.scTrackId, t.id);
        }
        out.ok += 1;
        out.results.push({ scId: t.sc_id, title: meta.title, scTrackId: meta.scTrackId });
      } catch (e) {
        out.failed += 1;
        out.results.push({ scId: t.sc_id, error: e.name === 'AbortError' ? 'timeout' : e.message });
      }
      // oEmbed is a free public endpoint; pace the calls rather than hammering it.
      await new Promise((r) => setTimeout(r, 700));
    }
    return out;
  }

  recordObservation(trackId, data) {
    const t = this.db.get('SELECT * FROM sc_tracks WHERE id = ?', trackId);
    if (!t) throw new Error('unknown track');
    const nums = {};
    for (const k of ['plays', 'likes', 'reposts', 'comments']) {
      if (data[k] !== undefined && data[k] !== null && data[k] !== '') {
        const n = Number(data[k]);
        if (!Number.isFinite(n) || n < 0) throw new Error(`${k} must be a non-negative number`);
        nums[k] = Math.round(n);
      }
    }
    if (!Object.keys(nums).length) throw new Error('enter at least one number');
    this.db.run(
      'INSERT INTO sc_observations (track_id, plays, likes, reposts, comments, note) VALUES (?, ?, ?, ?, ?, ?)',
      trackId, nums.plays ?? null, nums.likes ?? null, nums.reposts ?? null, nums.comments ?? null, data.note || null
    );
    return this.db.get('SELECT * FROM sc_observations WHERE track_id = ? ORDER BY id DESC LIMIT 1', trackId);
  }

  totals() {
    const rows = this.db.all(
      `SELECT t.sc_id, t.title, o.plays, o.likes, o.reposts
       FROM sc_tracks t
       LEFT JOIN sc_observations o ON o.id = (
         SELECT id FROM sc_observations WHERE track_id = t.id ORDER BY observed_at DESC, id DESC LIMIT 1
       )`
    );
    const total = { plays: 0, likes: 0, reposts: 0 };
    for (const r of rows) {
      for (const k of ['plays', 'likes', 'reposts']) if (r[k] != null) total[k] += r[k];
    }
    return { total, tracks: rows };
  }
}

module.exports = { SoundCloud, fetchOembed, scIdFromUrl, DEFAULT_TRACKS };