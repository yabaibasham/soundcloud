// language: javascript, file: src/pitches.js, runtime: Node 24+, target: any
// Playlist pitch tracker. This is the one piece of promotion that keeps working
// after you stop posting, so it gets its own state machine rather than living as a
// line in the campaign planner.
//
// Real submission routes only. Curator names below are real, publicly-listed,
// independent-playlist curators that accept submissions through their own stated
// channels — no scraped lists, no purchased contacts, no guessed email addresses.
// Anything personalised is left as a task for the artist to fill in themselves.
'use strict';

const STATUSES = [
  { key: 'to_pitch', label: 'To pitch', color: 'dim' },
  { key: 'submitted', label: 'Submitted', color: 'warn' },
  { key: 'in_review', label: 'In review', color: 'warn' },
  { key: 'shortlisted', label: 'Shortlisted', color: 'ok' },
  { key: 'accepted', label: 'Accepted', color: 'ok' },
  { key: 'declined', label: 'Declined', color: 'err' },
  { key: 'no_response', label: 'No response', color: 'dim' },
];

// Route types rather than personal contacts: these are the public submission
// channels curators actually publish, so nothing here has to be scraped or bought.
const ROUTES = [
  { key: 'submithub', label: 'SubmitHub', detail: 'Paid premium review option, ~$2/submission. 48h turnaround, no guarantee.' },
  { key: 'groover', label: 'Groover', detail: 'Pays per stream guaranteed, ~$3/track. Guaranteed listen, not guaranteed playlist add.' },
  { key: 'dailyplaylists', label: 'Daily Playlists', detail: 'Free submission, editorial review, slower turnaround.' },
  { key: 'soundcloud', label: 'SoundCloud for Artists', detail: 'Submit to editorial playlists from your own dashboard.' },
  { key: 'spotify', label: 'Spotify for Artists', detail: 'Pitch unreleased music ~7 days ahead, one song at a time.' },
  { key: 'direct', label: 'Direct email', detail: 'Independent blog/playlist with a public submission address.' },
  { key: 'radio', label: 'Campus / community radio', detail: 'Music submission via the station\'s listed address or form.' },
];

const TRACK_NOTES = {
  'basham_x/demons-and-daemons': 'Flagship, longest-established. Lead with this one.',
  'basham_x/velvet-damage-basham': 'Hard, no hook chorus. Pitch to curators who like a challenge.',
  'basham_x/rainy-days-basham': 'Mood piece. Strongest for editorial that follows mood.',
  'basham_x/see-me-on-my-grind-basham': 'Freestyle. Best fit for open-format and freestyle playlists.',
  'basham_x/wild-fire-basham': 'Biggest reach track. Priority for the release week push.',
};

// Real, publicly-listed independent curators across hip-hop/rap playlists.
// Contact details are intentionally NOT pre-filled: use each curator's stated
// submission channel. Fabricating addresses is how artists end up blacklisted.
const CURATORS = [
  { name: 'Daily Playlists', route: 'dailyplaylists', focus: 'hip-hop, rap, emerging artists', note: 'Free editorial submission' },
  { name: 'Groover', route: 'groover', focus: 'any genre, algorithmic + editorial', note: 'Paid per-stream model' },
  { name: 'SubmitHub', route: 'submithub', focus: 'all genres, blog + playlist review', note: 'Two submission tiers' },
  { name: 'SoundCloud for Artists editorial', route: 'soundcloud', focus: 'all genres, platform editorial', note: 'Submit from your own dashboard' },
  { name: 'Spotify editorial (for artists)', route: 'spotify', focus: 'all genres, platform editorial', note: 'Unreleased only, 7-day lead' },
  { name: 'Triple J Unearthed', route: 'direct', focus: 'Australian emerging, hip-hop leaning', note: 'Has an open submission process' },
  { name: 'Community radio (local campus stations)', route: 'radio', focus: 'local + emerging', note: 'List your nearest stations here' },
  { name: 'Student hip-hop blog', route: 'direct', focus: 'reviews, interviews, features', note: 'Find one in your city' },
];

const PITCH_SCHEMA = `
CREATE TABLE IF NOT EXISTS pitches (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  track_id      INTEGER REFERENCES sc_tracks(id) ON DELETE CASCADE,
  track_sc_id   TEXT NOT NULL,
  curator       TEXT NOT NULL,
  route         TEXT NOT NULL DEFAULT 'direct',
  focus         TEXT NOT NULL DEFAULT '',
  status        TEXT NOT NULL DEFAULT 'to_pitch',
  submitted_at  TEXT,
  responded_at  TEXT,
  plays_7d      INTEGER,
  note          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pitch_status ON pitches(status);
CREATE INDEX IF NOT EXISTS idx_pitch_track  ON pitches(track_sc_id);
`;

class Pitches {
  constructor(db) {
    this.db = db;
  }

  seedIfEmpty() {
    const n = this.db.get('SELECT COUNT(*) AS n FROM pitches').n;
    if (n > 0) return 0;
    const tracks = this.db.all('SELECT id, sc_id FROM sc_tracks');
    if (!tracks.length) return 0;

    const ids = tracks.map((t) => ({ db: t.id, sc: t.sc_id }));
    let created = 0;

    this.db.transaction(() => {
      // Every track goes to every real route. That is the point of a pitch list:
      // breadth first, then follow up on the ones that actually answer.
      for (const t of ids) {
        for (const c of CURATORS) {
          this.db.run(
            `INSERT INTO pitches (track_id, track_sc_id, curator, route, focus, note)
             VALUES (?, ?, ?, ?, ?, ?)`,
            t.db, t.sc, c.name, c.route, c.focus,
            TRACK_NOTES[t.sc] ? `${c.note}. ${TRACK_NOTES[t.sc]}` : c.note
          );
          created += 1;
        }
      }
    });
    return created;
  }

  list() {
    return {
      statuses: STATUSES,
      routes: ROUTES,
      tracks: this.db.all('SELECT id, sc_id, title FROM sc_tracks ORDER BY id'),
      pitches: this.db.all('SELECT * FROM pitches ORDER BY track_sc_id, curator'),
      stats: this.stats(),
    };
  }

  stats() {
    const rows = this.db.all('SELECT status, COUNT(*) AS n FROM pitches GROUP BY status');
    const byStatus = Object.fromEntries(STATUSES.map((s) => [s.key, 0]));
    for (const r of rows) byStatus[r.status] = r.n;
    const total = rows.reduce((a, r) => a + r.n, 0);
    // "Touched" = anything beyond the untouched backlog. This is the number that
    // actually moves, as opposed to rows that exist but were never sent.
    const touched = total - (byStatus.to_pitch || 0);
    const landed = byStatus.accepted || 0;
    const submitted = touched - landed - (byStatus.declined || 0) - (byStatus.no_response || 0);
    return {
      total,
      byStatus,
      touched,
      submitted,
      landed,
      // Of everything actually submitted, what share landed in a playlist.
      hitRate: submitted > 0 ? Number(((landed / submitted) * 100).toFixed(1)) : 0,
    };
  }

  update(id, body) {
    const p = this.db.get('SELECT * FROM pitches WHERE id = ?', id);
    if (!p) throw Object.assign(new Error('Unknown pitch.'), { status: 404 });

    const status = body.status === undefined ? p.status : String(body.status);
    if (!STATUSES.some((s) => s.key === status)) {
      throw Object.assign(new Error(`status must be one of: ${STATUSES.map((s) => s.key).join(', ')}`), { status: 400 });
    }

    // Stamp dates on transition so the history is automatic rather than manual.
    let submittedAt = p.submitted_at;
    let respondedAt = p.responded_at;
    if (status === 'submitted' && !submittedAt) submittedAt = new Date().toISOString();
    if (['shortlisted', 'accepted', 'declined', 'no_response'].includes(status) && !respondedAt) {
      respondedAt = new Date().toISOString();
    }

    let plays7d = p.plays_7d;
    if (body.plays7d !== undefined && body.plays7d !== null && body.plays7d !== '') {
      const n = Number(body.plays7d);
      if (!Number.isFinite(n) || n < 0) throw Object.assign(new Error('plays7d must be a non-negative number.'), { status: 400 });
      plays7d = Math.round(n);
    }

    this.db.run(
      'UPDATE pitches SET status = ?, submitted_at = ?, responded_at = ?, plays_7d = ?, note = ? WHERE id = ?',
      status, submittedAt, respondedAt, plays7d,
      body.note === undefined ? p.note : (body.note ? String(body.note) : null),
      id
    );
    return this.db.get('SELECT * FROM pitches WHERE id = ?', id);
  }

  add(body) {
    const trackSc = String(body.trackScId || '').trim();
    const curator = String(body.curator || '').trim();
    if (!trackSc) throw Object.assign(new Error('trackScId is required.'), { status: 400 });
    if (!curator) throw Object.assign(new Error('curator is required.'), { status: 400 });
    const route = ROUTES.some((r) => r.key === body.route) ? body.route : 'direct';
    const track = this.db.get('SELECT id FROM sc_tracks WHERE sc_id = ?', trackSc);
    this.db.run(
      'INSERT INTO pitches (track_id, track_sc_id, curator, route, focus, note) VALUES (?, ?, ?, ?, ?, ?)',
      track ? track.id : null, trackSc, curator, route, String(body.focus || ''), body.note ? String(body.note) : null
    );
    const r = this.db.get('SELECT id FROM pitches ORDER BY id DESC LIMIT 1');
    return this.db.get('SELECT * FROM pitches WHERE id = ?', r.id);
  }

  remove(id) {
    this.db.run('DELETE FROM pitches WHERE id = ?', id);
  }

  csv() {
    const rows = this.db.all(
      'SELECT track_sc_id, curator, route, focus, status, submitted_at, responded_at, plays_7d, note FROM pitches ORDER BY track_sc_id, curator'
    );
    const q = (v) => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = ['track,curator,route,focus,status,submitted_at,responded_at,plays_7d,note'];
    for (const r of rows) {
      lines.push([r.track_sc_id, r.curator, r.route, r.focus, r.status, r.submitted_at, r.responded_at, r.plays_7d, r.note].map(q).join(','));
    }
    return lines.join('\r\n');
  }
}

module.exports = { Pitches, PITCH_SCHEMA, STATUSES, ROUTES, CURATORS };