// language: javascript, file: mock-server.js, runtime: Node 20+, target: local dev host
// A rate-limited HTTP target you control. Gives the harness a real server to exercise:
// configurable latency, jitter, a slow path, and a sliding-window limiter that emits
// 429 + Retry-After once the window budget is spent.
'use strict';

const http = require('node:http');
const { parseArgs } = require('node:util');

const { values: v } = parseArgs({
  options: {
    port: { type: 'string', default: '8787' },
    latency: { type: 'string', default: '40' },
    jitter: { type: 'string', default: '30' },
    limit: { type: 'string', default: '120' },
    window: { type: 'string', default: '60000' },
    'slow-every': { type: 'string', default: '10' },
    'slow-ms': { type: 'string', default: '900' },
    host: { type: 'string', default: '127.0.0.1' },
    token: { type: 'string', default: '' },
    verbose: { type: 'boolean', default: false },
    help: { type: 'boolean', default: false },
  },
});

if (v.help) {
  process.stdout.write(
    'mock-server.js [options]\n' +
      '  --port <n>          listen port (default 8787)\n' +
      '  --latency <ms>      baseline artificial latency (default 40)\n' +
      '  --jitter <ms>       +/- random latency (default 30)\n' +
      '  --limit <n>         requests permitted per window (default 120)\n' +
      '  --window <ms>       sliding window width (default 60000)\n' +
      '  --slow-every <n>    every Nth request takes the slow path (default 10, 0 disables)\n' +
      '  --slow-ms <ms>      slow-path duration (default 900)\n' +
      '  --host <addr>       bind address (default 127.0.0.1; 0.0.0.0 exposes to LAN/internet)\n' +
      '  --token <secret>    require "Authorization: Bearer <secret>" on every route\n' +
      '  --verbose           log every request\n'
  );
  process.exit(0);
}

const PORT = Number(v.port);
const HOST = v.host;
const TOKEN = v.token;
const BASE_LATENCY = Number(v.latency);
const JITTER = Number(v.jitter);
const LIMIT = Number(v.limit);
const WINDOW = Number(v.window);
const SLOW_EVERY = Number(v['slow-every']);
const SLOW_MS = Number(v['slow-ms']);

let requestCounter = 0;
const hitTimestamps = [];

// Sliding window: returns seconds until a slot frees up, or 0 when the request is admitted.
function admit() {
  const now = Date.now();
  while (hitTimestamps.length && hitTimestamps[0] <= now - WINDOW) hitTimestamps.shift();
  if (hitTimestamps.length >= LIMIT) {
    return Math.max(1, Math.ceil((hitTimestamps[0] + WINDOW - now) / 1000));
  }
  hitTimestamps.push(now);
  return 0;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function sendJson(res, status, payload, headers = {}) {
  const body = Buffer.from(JSON.stringify(payload));
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'cache-control': 'no-store',
    ...headers,
  });
  res.end(body);
}

function makeItems(n) {
  const out = [];
  for (let i = 0; i < n; i += 1) {
    out.push({
      id: i + 1,
      sku: `SKU-${String(i + 1).padStart(5, '0')}`,
      name: `Widget ${i + 1}`,
      price: Number(((i * 7.35) % 400 + 1).toFixed(2)),
      inStock: i % 5 !== 0,
    });
  }
  return out;
}

const server = http.createServer(async (req, res) => {
  const started = process.hrtime.bigint();
  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  // Auth precedes the limiter so unauthorized traffic cannot burn the rate budget
  // that legitimate callers are entitled to.
  if (TOKEN) {
    const presented = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const given = Buffer.from(presented);
    const want = Buffer.from(TOKEN);
    const okAuth = given.length === want.length && require('node:crypto').timingSafeEqual(given, want);
    if (!okAuth) {
      sendJson(res, 401, { error: 'unauthorized' }, { 'www-authenticate': 'Bearer' });
      return;
    }
  }

  const retryAfter = admit();
  if (retryAfter > 0) {
    if (v.verbose) console.log(`429 ${req.method} ${url.pathname}`);
    sendJson(
      res,
      429,
      { error: 'rate_limited', limit: LIMIT, window_ms: WINDOW, retry_after_s: retryAfter },
      { 'retry-after': String(retryAfter) }
    );
    return;
  }

  requestCounter += 1;
  const seq = requestCounter;
  if (SLOW_EVERY > 0 && seq % SLOW_EVERY === 0) await sleep(SLOW_MS);
  else await sleep(Math.max(0, BASE_LATENCY + (Math.random() * 2 - 1) * JITTER));

  const route = `${req.method} ${url.pathname}`;

  if (route === 'GET /health') {
    sendJson(res, 200, { status: 'ok', uptime_s: Math.round(process.uptime()), served: seq });
    return;
  }

  if (route === 'GET /api/catalog') {
    const page = Number(url.searchParams.get('page') || '1');
    const size = Math.min(100, Number(url.searchParams.get('size') || '25'));
    sendJson(res, 200, { page, size, total: 10_000, items: makeItems(size) });
    return;
  }

  if (route === 'GET /api/item') {
    const id = Number(url.searchParams.get('id'));
    if (!Number.isInteger(id) || id < 1 || id > 10_000) {
      sendJson(res, 400, { error: 'bad_id', detail: 'id must be an integer 1..10000' });
      return;
    }
    sendJson(res, 200, { id, sku: `SKU-${String(id).padStart(5, '0')}`, name: `Widget ${id}` });
    return;
  }

  if (route === 'GET /api/slow') {
    await sleep(SLOW_MS);
    sendJson(res, 200, { status: 'deliberately_slow', ms: SLOW_MS });
    return;
  }

  sendJson(res, 404, { error: 'not_found', route });

  if (v.verbose) {
    const ms = Number(process.hrtime.bigint() - started) / 1e6;
    console.log(`${String(seq).padStart(6)} ${ms.toFixed(1).padStart(8)}ms  ${route}`);
  }
});

server.listen(PORT, HOST, () => {
  const exposure = HOST === '0.0.0.0' || HOST === '::'
    ? 'ALL INTERFACES - reachable from your LAN and, if the port is forwarded or the host is public, the internet'
    : HOST === '127.0.0.1'
      ? 'loopback only (this machine only)'
      : `bound to ${HOST}`;
  console.log(`mock-server listening on http://${HOST}:${PORT}`);
  console.log(`  exposure: ${exposure}`);
  console.log(`  auth: ${TOKEN ? 'bearer token required' : 'NONE - open to anything that can reach this port'}`);
  console.log(`  latency ${BASE_LATENCY}ms +/-${JITTER}ms | slow path every ${SLOW_EVERY || 'off'} @ ${SLOW_MS}ms`);
  console.log(`  limit ${LIMIT} requests / ${WINDOW}ms  ->  429 + Retry-After when exceeded`);
  console.log('  routes: /health  /api/catalog?page&size  /api/item?id  /api/slow');

  if ((HOST === '0.0.0.0' || HOST === '::') && !TOKEN) {
    console.log('\n  WARNING: exposed without --token. Anyone who can reach this port can drive it.');
  }
});